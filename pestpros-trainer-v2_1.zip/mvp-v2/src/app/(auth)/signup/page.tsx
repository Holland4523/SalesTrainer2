'use client';
// src/app/(auth)/signup/page.tsx

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';

const C = {
  bg: '#07090F', surface: '#0F1520', card: '#141E2E',
  amber: '#F59E0B', text: '#EFF6FF', muted: 'rgba(239,246,255,.55)',
  faint: 'rgba(239,246,255,.2)', border: '#ffffff0d', red: '#EF4444',
};

export default function SignupPage() {
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [name,     setName]     = useState('');
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');
  const [done,     setDone]     = useState(false);
  const router = useRouter();

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, name }),
    });
    const data = await res.json();
    if (!res.ok) { setError(data.error || 'Signup failed'); setLoading(false); return; }
    setDone(true);
  }

  if (done) return (
    <div style={wrapStyle}>
      <div style={cardStyle}>
        <div style={{ fontSize: 36, marginBottom: 12 }}>✓</div>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: C.amber, marginBottom: 8 }}>Check your email</h2>
        <p style={{ fontSize: 13, color: C.muted, lineHeight: 1.6 }}>
          We sent a confirmation link to <strong style={{ color: C.text }}>{email}</strong>.<br />
          Click it to activate your account, then come back to sign in.
        </p>
        <button onClick={() => router.push('/login')} style={btnStyle}>Go to Login</button>
      </div>
    </div>
  );

  return (
    <div style={wrapStyle}>
      <div style={cardStyle}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 24 }}>
          <div style={{ width: 32, height: 32, borderRadius: 7, background: `linear-gradient(135deg, ${C.amber}, #92400E)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>🏠</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700 }}>PestPros AI Trainer</div>
            <div style={{ fontSize: 9, color: C.amber, letterSpacing: '.12em', fontFamily: 'monospace' }}>SALES TRAINING PLATFORM</div>
          </div>
        </div>

        <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 4 }}>Create your account</h1>
        <p style={{ fontSize: 13, color: C.muted, marginBottom: 24 }}>
          Start with 3 free sessions. No credit card required.
        </p>

        <form onSubmit={handleSignup}>
          <label style={labelStyle}>Full Name</label>
          <input type="text" required value={name} onChange={e => setName(e.target.value)} style={inputStyle} placeholder="Holland Carter" />

          <label style={{ ...labelStyle, marginTop: 14 }}>Email</label>
          <input type="email" required value={email} onChange={e => setEmail(e.target.value)} style={inputStyle} placeholder="you@company.com" />

          <label style={{ ...labelStyle, marginTop: 14 }}>Password</label>
          <input type="password" required minLength={8} value={password} onChange={e => setPassword(e.target.value)} style={inputStyle} placeholder="8+ characters" />

          {error && <p style={{ margin: '12px 0 0', color: C.red, fontSize: 13 }}>{error}</p>}

          <button type="submit" disabled={loading} style={{ ...btnStyle, marginTop: 24 }}>
            {loading ? 'Creating account…' : 'Create Account →'}
          </button>
        </form>

        <p style={{ marginTop: 20, fontSize: 12, color: C.faint, textAlign: 'center' }}>
          Already have an account?{' '}
          <a href="/login" style={{ color: C.amber, textDecoration: 'none' }}>Sign in</a>
        </p>

        {/* Pricing teaser */}
        <div style={{ marginTop: 28, padding: '14px 16px', background: C.surface, borderRadius: 8, border: `1px solid ${C.border}` }}>
          <p style={{ fontSize: 9, color: C.amber, letterSpacing: '.1em', fontFamily: 'monospace', marginBottom: 8 }}>PLANS AFTER FREE TRIAL</p>
          {[
            { name: 'Starter', price: '$19/mo', sessions: '20 sessions' },
            { name: 'Pro',     price: '$39/mo', sessions: '60 sessions' },
            { name: 'Team',    price: '$99/mo', sessions: 'Unlimited + 5 reps' },
          ].map(p => (
            <div key={p.name} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: `1px solid ${C.border}` }}>
              <span style={{ fontSize: 12, color: C.muted }}>{p.name}</span>
              <span style={{ fontSize: 12, color: C.text }}>{p.sessions}</span>
              <span style={{ fontSize: 12, color: C.amber, fontFamily: 'monospace' }}>{p.price}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const wrapStyle: React.CSSProperties = { minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#07090F', padding: 20 };
const cardStyle: React.CSSProperties = { width: 420, background: '#141E2E', borderRadius: 12, padding: 36, border: '1px solid #ffffff0d' };
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 11, fontWeight: 600, color: 'rgba(239,246,255,.4)', letterSpacing: '.08em', fontFamily: 'monospace', marginBottom: 6 };
const inputStyle: React.CSSProperties = { width: '100%', padding: '10px 12px', background: '#07090F', border: '1px solid #ffffff15', borderRadius: 7, color: '#EFF6FF', fontSize: 14, boxSizing: 'border-box', outline: 'none' };
const btnStyle: React.CSSProperties = { width: '100%', padding: 12, background: '#F59E0B', color: '#000', border: 'none', borderRadius: 7, fontSize: 14, fontWeight: 700, cursor: 'pointer' };
