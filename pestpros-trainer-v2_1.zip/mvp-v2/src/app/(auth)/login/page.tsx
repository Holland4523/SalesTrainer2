'use client';
// src/app/(auth)/login/page.tsx

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';

const C = {
  bg: '#07090F', card: '#141E2E', amber: '#F59E0B',
  text: '#EFF6FF', muted: 'rgba(239,246,255,.55)',
  faint: 'rgba(239,246,255,.2)', border: '#ffffff0d', red: '#EF4444',
};

export default function LoginPage() {
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');
  const router = useRouter();

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const supabase = createClient();
    const { error: authErr } = await supabase.auth.signInWithPassword({ email, password });
    if (authErr) { setError(authErr.message); setLoading(false); return; }
    router.push('/dashboard');
  }

  return (
    <div style={wrapStyle}>
      <div style={cardStyle}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 28 }}>
          <div style={{ width: 32, height: 32, borderRadius: 7, background: `linear-gradient(135deg, ${C.amber}, #92400E)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>🏠</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700 }}>PestPros AI Trainer</div>
            <div style={{ fontSize: 9, color: C.amber, letterSpacing: '.12em', fontFamily: 'monospace' }}>SALES TRAINING PLATFORM</div>
          </div>
        </div>

        <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 4 }}>Welcome back</h1>
        <p style={{ fontSize: 13, color: C.muted, marginBottom: 24 }}>Sign in to your account</p>

        <form onSubmit={handleLogin}>
          <label style={labelStyle}>Email</label>
          <input type="email" required value={email} onChange={e => setEmail(e.target.value)} style={inputStyle} placeholder="you@company.com" />

          <label style={{ ...labelStyle, marginTop: 14 }}>Password</label>
          <input type="password" required value={password} onChange={e => setPassword(e.target.value)} style={inputStyle} placeholder="••••••••" />

          {error && <p style={{ margin: '12px 0 0', color: C.red, fontSize: 13 }}>{error}</p>}

          <button type="submit" disabled={loading} style={{ ...btnStyle, marginTop: 24 }}>
            {loading ? 'Signing in…' : 'Sign In →'}
          </button>
        </form>

        <p style={{ marginTop: 16, fontSize: 12, color: C.faint, textAlign: 'center' }}>
          No account?{' '}
          <a href="/signup" style={{ color: C.amber, textDecoration: 'none' }}>Create one free</a>
        </p>
      </div>
    </div>
  );
}

const wrapStyle: React.CSSProperties = { minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#07090F', padding: 20 };
const cardStyle: React.CSSProperties = { width: 400, background: '#141E2E', borderRadius: 12, padding: 36, border: '1px solid #ffffff0d' };
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 11, fontWeight: 600, color: 'rgba(239,246,255,.4)', letterSpacing: '.08em', fontFamily: 'monospace', marginBottom: 6 };
const inputStyle: React.CSSProperties = { width: '100%', padding: '10px 12px', background: '#07090F', border: '1px solid #ffffff15', borderRadius: 7, color: '#EFF6FF', fontSize: 14, boxSizing: 'border-box', outline: 'none' };
const btnStyle: React.CSSProperties = { width: '100%', padding: 12, background: '#F59E0B', color: '#000', border: 'none', borderRadius: 7, fontSize: 14, fontWeight: 700, cursor: 'pointer' };
