'use client';
// src/app/pricing/page.tsx

import { useState } from 'react';
import { useRouter } from 'next/navigation';

const C = {
  bg: '#07090F', surface: '#0F1520', card: '#141E2E',
  amber: '#F59E0B', amberBg: 'rgba(245,158,11,.1)',
  green: '#10B981', blue: '#3B82F6',
  text: '#EFF6FF', muted: 'rgba(239,246,255,.55)',
  faint: 'rgba(239,246,255,.22)', border: '#ffffff0d',
};

const PLANS = [
  {
    key: 'starter',
    name: 'Starter',
    price: 19,
    sessions: '20 sessions/mo',
    desc: 'Perfect for individual reps',
    features: ['20 training sessions/month', 'All 4 homeowner personalities', 'All 4 difficulty levels', 'GPT-4o-mini homeowner AI', 'Whisper voice transcription', 'Real-time TTS homeowner voice', 'Score breakdown + AI coaching', 'Session transcripts'],
    color: C.blue,
    highlight: false,
  },
  {
    key: 'pro',
    name: 'Pro',
    price: 39,
    sessions: '60 sessions/mo',
    desc: 'For reps training daily',
    features: ['60 training sessions/month', 'Everything in Starter', 'Performance trend charts', 'Export session transcripts', 'Priority AI response speed'],
    color: C.amber,
    highlight: true,
  },
  {
    key: 'team',
    name: 'Team',
    price: 99,
    sessions: 'Unlimited sessions',
    desc: 'For managers + their reps',
    features: ['Unlimited sessions', 'Up to 5 rep accounts', 'Manager dashboard', 'Score review queue', 'Team leaderboard', 'Everything in Pro'],
    color: C.green,
    highlight: false,
  },
];

export default function PricingPage() {
  const [loading, setLoading] = useState<string | null>(null);
  const router = useRouter();

  async function subscribe(plan: string) {
    setLoading(plan);
    const res = await fetch('/api/stripe/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan }),
    });
    if (res.status === 401) { router.push('/login'); return; }
    const { url, error } = await res.json();
    if (error) { alert(error); setLoading(null); return; }
    window.location.href = url;
  }

  return (
    <div style={{ minHeight: '100vh', background: C.bg, padding: '60px 24px' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: 52 }}>
        <div style={{ fontSize: 11, color: C.amber, letterSpacing: '.14em', fontFamily: 'monospace', marginBottom: 10 }}>PRICING</div>
        <h1 style={{ fontSize: 36, fontWeight: 800, marginBottom: 12 }}>Train like the top 1%</h1>
        <p style={{ fontSize: 16, color: C.muted, maxWidth: 480, margin: '0 auto' }}>
          Real AI homeowners. Real objections. Real scoring. Start free with 3 sessions.
        </p>
      </div>

      {/* Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20, maxWidth: 960, margin: '0 auto 52px' }}>
        {PLANS.map(p => (
          <div key={p.key} style={{
            background: C.card, border: `1px solid ${p.highlight ? p.color + '50' : C.border}`,
            borderRadius: 12, padding: '28px 26px', position: 'relative',
            boxShadow: p.highlight ? `0 0 30px ${p.color}20` : 'none',
          }}>
            {p.highlight && (
              <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', background: C.amber, color: '#000', fontSize: 10, fontWeight: 800, padding: '3px 12px', borderRadius: 20, letterSpacing: '.08em', fontFamily: 'monospace' }}>
                MOST POPULAR
              </div>
            )}

            <div style={{ fontSize: 11, color: p.color, letterSpacing: '.12em', fontFamily: 'monospace', marginBottom: 6 }}>{p.key.toUpperCase()}</div>
            <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 3 }}>{p.name}</div>
            <div style={{ fontSize: 13, color: C.muted, marginBottom: 20 }}>{p.desc}</div>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 6 }}>
              <span style={{ fontSize: 42, fontWeight: 800, color: p.color, fontFamily: 'monospace' }}>${p.price}</span>
              <span style={{ fontSize: 13, color: C.faint }}>/month</span>
            </div>
            <div style={{ fontSize: 12, color: C.muted, marginBottom: 24, fontFamily: 'monospace' }}>{p.sessions}</div>

            <button
              onClick={() => subscribe(p.key)}
              disabled={loading === p.key}
              style={{
                width: '100%', padding: '12px', borderRadius: 7, border: 'none',
                background: p.highlight ? C.amber : 'transparent',
                color: p.highlight ? '#000' : p.color,
                border: p.highlight ? 'none' : `1px solid ${p.color}50`,
                fontSize: 14, fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer',
                marginBottom: 24, opacity: loading === p.key ? .6 : 1,
              } as any}
            >
              {loading === p.key ? 'Redirecting…' : `Get ${p.name} →`}
            </button>

            <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 18 }}>
              {p.features.map(f => (
                <div key={f} style={{ display: 'flex', gap: 9, alignItems: 'flex-start', marginBottom: 8 }}>
                  <span style={{ color: p.color, fontSize: 12, lineHeight: 1.6 }}>✓</span>
                  <span style={{ fontSize: 12, color: C.muted, lineHeight: 1.6 }}>{f}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Free tier note */}
      <div style={{ textAlign: 'center', padding: '20px', background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, maxWidth: 520, margin: '0 auto 36px' }}>
        <p style={{ fontSize: 14, color: C.muted }}>
          <strong style={{ color: C.text }}>Free tier:</strong> 3 sessions included when you sign up. No credit card required.
        </p>
      </div>

      <div style={{ textAlign: 'center' }}>
        <a href="/dashboard" style={{ color: C.faint, fontSize: 13, textDecoration: 'none' }}>← Back to dashboard</a>
      </div>
    </div>
  );
}
