// src/app/api/session/transcript/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient, createServiceClient } from '@/lib/supabase/server';

export async function GET(req: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const id = new URL(req.url).searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 });

  const db = createServiceClient();
  const { data: session } = await db
    .from('sessions').select('user_id').eq('id', id).single();

  if (!session || session.user_id !== user.id) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const { data: rows } = await db
    .from('transcripts')
    .select('speaker, text, turn_index')
    .eq('session_id', id)
    .order('turn_index', { ascending: true });

  return NextResponse.json({ rows: rows ?? [] });
}
