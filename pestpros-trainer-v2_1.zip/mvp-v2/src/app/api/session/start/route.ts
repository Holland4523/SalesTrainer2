// src/app/api/session/start/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createServerClient, createServiceClient } from '@/lib/supabase/server';
import { runSimulatorTurn } from '@/lib/openai';
import { checkSessionAllowance } from '@/lib/subscription';

export async function POST(req: NextRequest) {
  const supabase = createServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  // ── SUBSCRIPTION CHECK ───────────────────────────────────────
  const allowance = await checkSessionAllowance(user.id);
  if (!allowance.allowed) {
    return NextResponse.json(
      { error: allowance.reason, upgradeRequired: true, used: allowance.used, limit: allowance.limit },
      { status: 402 }
    );
  }

  const { scenarioType, difficulty } = await req.json();
  const svc = createServiceClient();

  // Get tenant
  const { data: userData } = await svc.from('users').select('tenant_id').eq('id', user.id).single();
  if (!userData) return NextResponse.json({ error: 'User not found' }, { status: 404 });

  // Create session
  const { data: session, error: sessionErr } = await svc.from('sessions').insert({
    tenant_id: userData.tenant_id,
    user_id: user.id,
    scenario_type: scenarioType,
    difficulty: String(difficulty),
    status: 'active',
  }).select().single();

  if (sessionErr) return NextResponse.json({ error: 'Failed to create session' }, { status: 500 });

  // Increment usage counter
  await svc.rpc('increment_session_usage', { p_tenant_id: userData.tenant_id });

  // Get opening line from simulator
  const systemPrompt = process.env.SIMULATOR_SYSTEM_PROMPT;
  if (!systemPrompt) return NextResponse.json({ error: 'Simulator not configured' }, { status: 500 });

  const openingLine = await runSimulatorTurn(systemPrompt, [], difficulty);

  // Log opening turn
  await svc.from('session_transcripts').insert({
    session_id: session.id,
    turn_number: 0,
    speaker: 'ai',
    content: openingLine,
  });

  return NextResponse.json({
    sessionId: session.id,
    openingLine,
    usage: { used: allowance.used + 1, limit: allowance.limit },
  });
}
