// src/app/api/session/score/route.ts
// Internal scoring route — called fire-and-forget after session ends.
// Guarded by x-internal-key header (not exposed to client).

import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase/server';
import { runScoringCall } from '@/lib/openai';
import { computeReadinessScore } from '@/types';
import { log, logError } from '@/lib/logger';
import type { DifficultyLevel } from '@/types';

const MAX_ATTEMPTS = 3;

export async function POST(req: NextRequest) {
  const key = req.headers.get('x-internal-key');
  if (key !== process.env.INTERNAL_API_KEY) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const { sessionId } = await req.json() as { sessionId: string };
  if (!sessionId) return NextResponse.json({ error: 'sessionId required' }, { status: 400 });

  const db = createServiceClient();

  // Fetch session first so we have tenant_id before creating the job
  const { data: session } = await db.from('sessions').select('*').eq('id', sessionId).single();
  if (!session) return NextResponse.json({ error: 'Session not found' }, { status: 404 });

  // Check for existing scoring job
  const { data: existing } = await db
    .from('scoring_jobs').select('*').eq('session_id', sessionId).single();

  if (existing?.status === 'completed') {
    return NextResponse.json({ ok: true, message: 'Already scored' });
  }
  if (existing && existing.attempts >= MAX_ATTEMPTS) {
    return NextResponse.json({ error: 'Max attempts exhausted' }, { status: 422 });
  }

  // Create or update job — tenant_id is now available from the session fetch above
  let jobId: string;
  if (existing) {
    await db.from('scoring_jobs').update({
      status:   'running',
      attempts: existing.attempts + 1,
    }).eq('id', existing.id);
    jobId = existing.id;
  } else {
    const { data: job, error: jobErr } = await db.from('scoring_jobs').insert({
      session_id:     sessionId,
      tenant_id:      session.tenant_id,
      status:         'running',
      attempts:       1,
      prompt_version: 'v1.0',
    }).select('id').single();
    if (jobErr || !job) return NextResponse.json({ error: 'Failed to create scoring job' }, { status: 500 });
    jobId = job.id;
  }

  await db.from('sessions').update({ status: 'scoring' }).eq('id', sessionId);

  // Fetch transcript
  const { data: rows } = await db
    .from('transcripts')
    .select('speaker, text, turn_index')
    .eq('session_id', sessionId)
    .order('turn_index', { ascending: true });

  const transcript = (rows ?? []).map(r => ({
    speaker:    r.speaker as 'rep' | 'ai',
    text:       r.text as string,
    turn_index: r.turn_index as number,
  }));

  if (transcript.length < 2) {
    await db.from('sessions').update({
      status:          'scored',
      session_quality: 'incomplete',
      scored_at:       new Date().toISOString(),
    }).eq('id', sessionId);
    await db.from('scoring_jobs').update({
      status:       'completed',
      completed_at: new Date().toISOString(),
    }).eq('id', jobId);
    return NextResponse.json({ ok: true, message: 'Too short to score' });
  }

  try {
    const result = await runScoringCall({
      transcript,
      difficultyLevel: session.difficulty_level as DifficultyLevel,
    });

    const { output } = result;
    const { readiness_score, raw_readiness_score, difficulty_multiplier } = computeReadinessScore(
      {
        opener_score:             output.opener_score,
        tonality_score:           output.tonality_score,
        question_stack_score:     output.question_stack_score,
        objection_handling_score: output.objection_handling_score,
        closing_score:            output.closing_score,
        resilience_score:         output.resilience_score,
      },
      session.difficulty_level as DifficultyLevel,
    );

    await db.from('scores').insert({
      session_id:               sessionId,
      user_id:                  session.user_id,
      tenant_id:                session.tenant_id,
      opener_score:             output.opener_score,
      tonality_score:           output.tonality_score,
      question_stack_score:     output.question_stack_score,
      objection_handling_score: output.objection_handling_score,
      closing_score:            output.closing_score,
      resilience_score:         output.resilience_score,
      readiness_score,
      raw_readiness_score,
      difficulty_level:         session.difficulty_level,
      difficulty_multiplier,
      scoring_prompt_version:   'v1.0',
      session_outcome:          output.session_outcome,
      scoring_notes:            output.scoring_notes,
      review_status:            'pending_review',
    });

    if (output.coaching_recommendations?.length) {
      await db.from('weak_areas').insert(
        output.coaching_recommendations.map(c => ({
          session_id:     sessionId,
          user_id:        session.user_id,
          tenant_id:      session.tenant_id,
          tag:            c.tag,
          recommendation: c.recommendation,
        }))
      );
    }

    await db.from('sessions').update({
      status:          'scored',
      scored_at:       new Date().toISOString(),
      session_quality: session.session_quality ?? 'valid',
      weak_area_tags:  output.weak_area_tags,
      session_outcome: output.session_outcome,
    }).eq('id', sessionId);

    await db.from('scoring_jobs').update({
      status:       'completed',
      completed_at: new Date().toISOString(),
    }).eq('id', jobId);

    log({
      sessionId,
      tenantId:  session.tenant_id,
      eventType: 'scoring_completed',
      message:   `Score: ${readiness_score}`,
      metadata:  { readiness_score, session_outcome: output.session_outcome },
    });

    return NextResponse.json({ ok: true, readiness_score });

  } catch (err) {
    logError('scoring_failed', err, { sessionId, tenantId: session.tenant_id });

    const attemptCount = existing ? existing.attempts + 1 : 1;
    if (attemptCount >= MAX_ATTEMPTS) {
      await db.from('sessions').update({
        status:          'scoring_failed',
        session_quality: 'scoring_failed',
      }).eq('id', sessionId);
      await db.from('scoring_jobs').update({
        status:     'exhausted',
        last_error: err instanceof Error ? err.message : String(err),
      }).eq('id', jobId);
    } else {
      await db.from('sessions').update({ status: 'completed' }).eq('id', sessionId);
      await db.from('scoring_jobs').update({
        status:     'pending',
        last_error: err instanceof Error ? err.message : String(err),
      }).eq('id', jobId);
    }

    return NextResponse.json({ error: 'Scoring failed' }, { status: 500 });
  }
}
