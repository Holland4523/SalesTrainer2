// src/app/api/session/end/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import { log } from '@/lib/logger';
import type { EndSessionRequest } from '@/types';

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { sessionId } = await req.json() as EndSessionRequest;
  if (!sessionId) return NextResponse.json({ error: 'sessionId required' }, { status: 400 });

  const db = createServiceClient();
  const { data: session } = await db
    .from('sessions').select('user_id, turn_count, tenant_id, status').eq('id', sessionId).single();

  if (!session) return NextResponse.json({ error: 'Session not found' }, { status: 404 });
  if (session.user_id !== user.id) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  if (!['active', 'pending'].includes(session.status)) {
    return NextResponse.json({ ok: true, message: 'Session already ended' });
  }

  const quality = session.turn_count < 4 ? 'abandoned' : 'valid';

  await db.from('sessions').update({
    status:             'completed',
    termination_reason: 'rep_ended',
    session_quality:    quality,
    ended_at:           new Date().toISOString(),
  }).eq('id', sessionId);

  log({
    sessionId,
    tenantId:  session.tenant_id,
    eventType: 'rep_ended',
    message:   `Rep ended at turn ${session.turn_count}. Quality: ${quality}`,
  });

  // Fire-and-forget scoring trigger.
  // Derive base URL from the incoming request so it works on any host/port.
  const base = process.env.NEXT_PUBLIC_APP_URL
    ?? `${req.nextUrl.protocol}//${req.nextUrl.host}`;
  fetch(`${base}/api/session/score`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json', 'x-internal-key': process.env.INTERNAL_API_KEY ?? '' },
    body:    JSON.stringify({ sessionId }),
  }).catch(err => console.error('[end] scoring trigger failed:', err.message));

  return NextResponse.json({ ok: true });
}
