// src/app/api/session/turn/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import { runSimulatorTurn } from '@/lib/openai';
import { log, logError } from '@/lib/logger';
import type { TurnRequest, TurnResponse, TerminationReason } from '@/types';

type ServiceClient = ReturnType<typeof createServiceClient>;

const COACHING_PATTERNS = [/how am i doing/i, /give me a hint/i, /what should i say/i, /help me/i];
const COACHING_REPLY = "I can't coach you mid-session — that's what the scoring is for. Keep going!";

async function buildHistory(
  db: ServiceClient,
  sessionId: string,
  currentTurnCount: number,
) {
  const { data: rows } = await db
    .from('transcripts')
    .select('speaker, text, turn_index')
    .eq('session_id', sessionId)
    .order('turn_index', { ascending: true });

  if (!rows) return [];

  const verbatimFrom = currentTurnCount > 10 ? 9 : 0;
  const history: Array<{ role: 'user' | 'assistant'; content: string }> = [];

  const toSummarize = rows.filter(r => r.turn_index < verbatimFrom);
  if (toSummarize.length > 0) {
    const summary = toSummarize
      .map(r => `${r.speaker === 'rep' ? 'Rep' : 'Homeowner'} (turn ${r.turn_index}): ${r.text}`)
      .join('\n');
    history.push({ role: 'user', content: `[Earlier conversation summary]\n${summary}` });
    history.push({ role: 'assistant', content: '[Acknowledged]' });
  }

  for (const row of rows.filter(r => r.turn_index >= verbatimFrom)) {
    history.push({
      role:    row.speaker === 'rep' ? 'user' : 'assistant',
      content: row.text,
    });
  }

  return history;
}

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json() as TurnRequest;
  const { sessionId, turnText, audioMetrics } = body;

  if (!sessionId || !turnText?.trim()) {
    return NextResponse.json({ error: 'sessionId and turnText required' }, { status: 400 });
  }

  const db = createServiceClient();

  const { data: session } = await db
    .from('sessions').select('*').eq('id', sessionId).single();

  if (!session) return NextResponse.json({ error: 'Session not found' }, { status: 404 });
  if (session.user_id !== user.id) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  if (session.status !== 'active') {
    return NextResponse.json({ error: 'Session not active', sessionEnded: true }, { status: 422 });
  }

  if (session.turn_count >= session.max_turns) {
    await db.from('sessions').update({
      status:             'completed',
      termination_reason: 'turn_limit',
      session_quality:    'valid',
      ended_at:           new Date().toISOString(),
    }).eq('id', sessionId);

    triggerScoring(sessionId, req);
    return NextResponse.json({
      replyText:         'Session complete — you reached the maximum number of turns.',
      sessionEnded:      true,
      terminationReason: 'turn_limit' satisfies TerminationReason,
    });
  }

  if (COACHING_PATTERNS.some(p => p.test(turnText))) {
    log({ sessionId, eventType: 'coaching_guard_fired', turnIndex: session.turn_count });
    return NextResponse.json({ replyText: COACHING_REPLY, sessionEnded: false });
  }

  const history = await buildHistory(db, sessionId, session.turn_count);

  const scenarioContext = session.scenario_object
    ? Object.entries(session.scenario_object as Record<string, string>)
        .map(([k, v]) => `${k}: ${v}`).join(', ')
    : 'standard scenario';

  let replyText: string;
  let terminationSignaled: boolean;

  try {
    const result = await runSimulatorTurn({ history, repTurn: turnText, scenarioContext });
    replyText           = result.replyText;
    terminationSignaled = result.terminationSignaled;
  } catch (err) {
    logError('simulator_call_failed', err, { sessionId, tenantId: session.tenant_id });
    return NextResponse.json({ error: 'Simulator unavailable' }, { status: 500 });
  }

  const newTurnCount = session.turn_count + 1;

  await db.from('transcripts').insert([
    {
      session_id: sessionId, user_id: user.id, tenant_id: session.tenant_id,
      turn_index: newTurnCount * 2 - 1, speaker: 'rep', text: turnText,
    },
    {
      session_id: sessionId, user_id: user.id, tenant_id: session.tenant_id,
      turn_index: newTurnCount * 2, speaker: 'ai', text: replyText,
    },
  ]);

  if (audioMetrics) {
    await db.from('audio_metrics').insert({
      session_id:          sessionId,
      user_id:             user.id,
      tenant_id:           session.tenant_id,
      turn_index:          newTurnCount,
      wpm:                 audioMetrics.wpm,
      response_latency_ms: audioMetrics.response_latency_ms,
      filler_word_count:   audioMetrics.filler_word_count,
      amplitude_mean:      audioMetrics.amplitude_mean,
    });
  }

  await db.from('sessions').update({ turn_count: newTurnCount }).eq('id', sessionId);

  if (terminationSignaled) {
    await db.from('sessions').update({
      status:             'completed',
      termination_reason: 'ai_terminated',
      session_quality:    'valid',
      ended_at:           new Date().toISOString(),
    }).eq('id', sessionId);

    log({ sessionId, eventType: 'ai_terminated', turnIndex: newTurnCount });
    triggerScoring(sessionId, req);

    return NextResponse.json({
      replyText,
      sessionEnded:      true,
      terminationReason: 'ai_terminated' satisfies TerminationReason,
    } satisfies TurnResponse);
  }

  return NextResponse.json({ replyText, sessionEnded: false } satisfies TurnResponse);
}

// Derives base URL from the incoming request so it works on any host/port.
function triggerScoring(sessionId: string, req: NextRequest): void {
  const base = process.env.NEXT_PUBLIC_APP_URL
    ?? `${req.nextUrl.protocol}//${req.nextUrl.host}`;
  fetch(`${base}/api/session/score`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json', 'x-internal-key': process.env.INTERNAL_API_KEY ?? '' },
    body:    JSON.stringify({ sessionId }),
  }).catch(err => console.error('[triggerScoring]', err.message));
}
