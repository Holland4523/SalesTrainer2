// src/app/api/stripe/checkout/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { stripe, PLANS, PlanKey } from '@/lib/stripe';
import { createServerClient } from '@/lib/supabase/server';
import { createServiceClient } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  const { plan } = await req.json() as { plan: PlanKey };
  if (!PLANS[plan]) return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });

  const supabase = createServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const svc = createServiceClient();
  const { data: userData } = await svc.from('users')
    .select('tenant_id, tenants(stripe_customer_id, name)')
    .eq('id', user.id)
    .single();

  if (!userData) return NextResponse.json({ error: 'User not found' }, { status: 404 });

  const tenant = userData.tenants as any;
  let customerId = tenant?.stripe_customer_id;

  // Create Stripe customer if not exists
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: user.email!,
      name: tenant?.name,
      metadata: { tenant_id: userData.tenant_id, user_id: user.id },
    });
    customerId = customer.id;
    await svc.from('tenants').update({ stripe_customer_id: customerId }).eq('id', userData.tenant_id);
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    payment_method_types: ['card'],
    mode: 'subscription',
    line_items: [{ price: PLANS[plan].priceId, quantity: 1 }],
    success_url: `${appUrl}/dashboard?upgrade=success`,
    cancel_url: `${appUrl}/pricing`,
    metadata: { tenant_id: userData.tenant_id, plan },
    subscription_data: {
      metadata: { tenant_id: userData.tenant_id, plan },
    },
  });

  return NextResponse.json({ url: session.url });
}
