// src/app/api/stripe/webhook/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { createServiceClient } from '@/lib/supabase/server';
import Stripe from 'stripe';

export const config = { api: { bodyParser: false } };

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig  = req.headers.get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err: any) {
    console.error('Webhook signature failed:', err.message);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  const svc = createServiceClient();

  // Log the event
  await svc.from('stripe_events').upsert({
    id: event.id,
    type: event.type,
    payload: event.data.object as any,
  });

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;
      const tenantId = session.metadata?.tenant_id;
      const plan     = session.metadata?.plan as string;
      const subId    = session.subscription as string;

      if (!tenantId || !subId) break;

      const sub = await stripe.subscriptions.retrieve(subId);
      const periodEnd = new Date(sub.current_period_end * 1000).toISOString();
      const limits: Record<string, number | null> = { starter: 20, pro: 60, team: null };

      await svc.from('tenants').update({
        stripe_subscription_id: subId,
        stripe_price_id: sub.items.data[0]?.price.id,
        plan_tier: plan as any,
        sub_status: 'active',
        current_period_end: periodEnd,
        sessions_limit: limits[plan] ?? 20,
        sessions_used_this_period: 0,
      }).eq('id', tenantId);
      break;
    }

    case 'invoice.payment_succeeded': {
      const invoice = event.data.object as Stripe.Invoice;
      if (invoice.billing_reason !== 'subscription_cycle') break;
      const subId = invoice.subscription as string;
      const sub = await stripe.subscriptions.retrieve(subId);
      const tenantId = sub.metadata?.tenant_id;
      if (!tenantId) break;
      const periodEnd = new Date(sub.current_period_end * 1000).toISOString();
      await svc.from('tenants').update({
        sub_status: 'active',
        current_period_end: periodEnd,
        sessions_used_this_period: 0, // reset on renewal
      }).eq('id', tenantId);
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice;
      const subId = invoice.subscription as string;
      if (!subId) break;
      const sub = await stripe.subscriptions.retrieve(subId);
      const tenantId = sub.metadata?.tenant_id;
      if (tenantId) {
        await svc.from('tenants').update({ sub_status: 'past_due' }).eq('id', tenantId);
      }
      break;
    }

    case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription;
      const tenantId = sub.metadata?.tenant_id;
      if (tenantId) {
        await svc.from('tenants').update({
          sub_status: 'canceled',
          plan_tier: 'free',
          sessions_limit: 3,
        }).eq('id', tenantId);
      }
      break;
    }
  }

  return NextResponse.json({ received: true });
}
