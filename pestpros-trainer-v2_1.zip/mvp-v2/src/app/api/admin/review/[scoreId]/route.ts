// src/app/api/admin/review/[scoreId]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient, createServiceClient } from '@/lib/supabase/server';

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ scoreId: string }> },
) {
  const { scoreId } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { data: profile } = await supabase.from('users').select('role').eq('id', user.id).single();
  if (profile?.role !== 'super_admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const db = createServiceClient();

  const { data: score } = await db.from('scores').select('*').eq('id', scoreId).single();
  if (!score) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const { data: session } = await db.from('sessions').select('*').eq('id', score.session_id).single();
  const { data: transcript } = await db
    .from('transcripts').select('*').eq('session_id', score.session_id).order('turn_index');
  const { data: weakAreas } = await db
    .from('weak_areas').select('*').eq('session_id', score.session_id);
  const { data: rep } = await db
    .from('users').select('email, full_name').eq('id', score.user_id).single();

  return NextResponse.json({ score, session, transcript: transcript ?? [], weakAreas: weakAreas ?? [], rep });
}
