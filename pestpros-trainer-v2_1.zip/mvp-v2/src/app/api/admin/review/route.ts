// src/app/api/admin/review/route.ts
// GET  — paginated review queue
// POST — submit review decision

import { NextRequest, NextResponse } from 'next/server';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import type { ReviewSubmitRequest } from '@/types';

async function assertSuperAdmin(supabase: Awaited<ReturnType<typeof createClient>>, userId: string) {
  const { data } = await supabase.from('users').select('role').eq('id', userId).single();
  if (data?.role !== 'super_admin') throw new Error('Forbidden');
}

export async function GET(req: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try { await assertSuperAdmin(supabase, user.id); }
  catch { return NextResponse.json({ error: 'Forbidden' }, { status: 403 }); }

  const url    = new URL(req.url);
  const status = url.searchParams.get('status') ?? undefined;

  const db = createServiceClient();
  let query = db
    .from('scores')
    .select(`
      id, readiness_score, difficulty_level, session_outcome,
      review_status, reviewed_at, scoring_prompt_version,
      sessions!inner(turn_count, created_at, user_id, tenant_id),
      users!user_id(email, full_name)
    `)
    .order('created_at', { ascending: true });

  if (status) query = query.eq('review_status', status);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  return NextResponse.json({ items: data ?? [] });
}

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try { await assertSuperAdmin(supabase, user.id); }
  catch { return NextResponse.json({ error: 'Forbidden' }, { status: 403 }); }

  const body = await req.json() as ReviewSubmitRequest;

  if (!body.scoreId || !body.outcome) {
    return NextResponse.json({ error: 'scoreId and outcome required' }, { status: 400 });
  }
  if (body.outcome === 'needs_adjustment' && !body.reviewer_notes?.trim()) {
    return NextResponse.json({ error: 'reviewer_notes required' }, { status: 400 });
  }

  const db = createServiceClient();
  const { error } = await db.from('scores').update({
    review_status:          body.outcome,
    reviewer_id:            user.id,
    reviewer_notes:         body.reviewer_notes,
    reviewed_at:            new Date().toISOString(),
    score_approved:         body.outcome === 'approved',
    score_adjustment_needed: body.outcome === 'needs_adjustment',
    prompt_version_reviewed: 'v1.0',
    corrected_readiness_score:           body.corrected_readiness_score ?? null,
    corrected_opener_score:              body.corrected_opener_score ?? null,
    corrected_tonality_score:            body.corrected_tonality_score ?? null,
    corrected_question_stack_score:      body.corrected_question_stack_score ?? null,
    corrected_objection_handling_score:  body.corrected_objection_handling_score ?? null,
    corrected_closing_score:             body.corrected_closing_score ?? null,
    corrected_resilience_score:          body.corrected_resilience_score ?? null,
  }).eq('id', body.scoreId);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
