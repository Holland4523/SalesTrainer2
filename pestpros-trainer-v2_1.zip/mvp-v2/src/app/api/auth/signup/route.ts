// src/app/api/auth/signup/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  const { email, password, name } = await req.json();
  if (!email || !password || !name) {
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
  }

  const supabase = createServiceClient();

  // 1. Create auth user
  const { data: authData, error: authErr } = await supabase.auth.admin.createUser({
    email,
    password,
    email_confirm: false,
    user_metadata: { full_name: name },
  });
  if (authErr) return NextResponse.json({ error: authErr.message }, { status: 400 });

  const userId = authData.user.id;
  const isAdmin = email.toLowerCase() === process.env.ADMIN_EMAIL?.toLowerCase();

  // 2. Create tenant
  const slug = email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '') + '-' + Date.now();
  const { data: tenant, error: tenantErr } = await supabase
    .from('tenants')
    .insert({
      name,
      slug,
      plan_tier: isAdmin ? 'team' : 'free',
      sessions_limit: isAdmin ? null : 3,
      sub_status: isAdmin ? 'active' : null,
    })
    .select()
    .single();

  if (tenantErr) {
    await supabase.auth.admin.deleteUser(userId);
    return NextResponse.json({ error: 'Failed to create account' }, { status: 500 });
  }

  // 3. Create user record
  const { error: userErr } = await supabase.from('users').insert({
    id: userId,
    tenant_id: tenant.id,
    email,
    full_name: name,
    role: isAdmin ? 'super_admin' : 'rep',
    is_admin: isAdmin,
  });

  if (userErr) {
    await supabase.auth.admin.deleteUser(userId);
    return NextResponse.json({ error: 'Failed to create user record' }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
