// src/app/(rep)/dashboard/page.tsx
import { redirect } from 'next/navigation';
import { createServerClient, createServiceClient } from '@/lib/supabase/server';
import Link from 'next/link';
import { UsageBanner } from '@/components/UsageBanner';

const C = {
  bg:'#07090F', surface:'#0F1520', card:'#141E2E',
  amber:'#F59E0B', blue:'#3B82F6', green:'#10B981', red:'#EF4444',
  text:'#EFF6FF', muted:'rgba(239,246,255,.55)', faint:'rgba(239,246,255,.22)',
  border:'#ffffff0d',
};

function sc(v: number) { return v >= 72 ? C.green : v >= 50 ? C.amber : C.red; }
function sg(v: number) { return v >= 85 ? 'Elite' : v >= 72 ? 'Strong' : v >= 55 ? 'Developing' : 'Needs Work'; }

export default async function DashboardPage() {
  const supabase = createServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const db = createServiceClient();

  const [{ data: userData }, { data: scores }, { data: recentSessions }] = await Promise.all([
    db.from('users')
      .select('full_name, is_admin, role, tenants(plan_tier, sub_status, sessions_used_this_period, sessions_limit, current_period_end)')
      .eq('id', user.id)
      .single(),
    db.from('scores')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10),
    db.from('sessions')
      .select('id, started_at, difficulty, status, outcome')
      .eq('user_id', user.id)
      .order('started_at', { ascending: false })
      .limit(8),
  ]);

  const tenant   = (userData?.tenants as any) ?? {};
  const isAdmin  = userData?.is_admin ?? false;
  const latest   = scores?.[0] ?? null;
  const previous = scores?.[1] ?? null;
  const trend    = latest && previous ? (latest as any).readiness_score - (previous as any).readiness_score : null;

  const dims = latest ? [
    { label:'Opener',     w:'22%', v:(latest as any).opener },
    { label:'Tonality',   w:'18%', v:(latest as any).tonality },
    { label:'Discovery',  w:'15%', v:(latest as any).discovery },
    { label:'Objections', w:'25%', v:(latest as any).objections },
    { label:'Closing',    w:'10%', v:(latest as any).closing },
    { label:'Resilience', w:'10%', v:(latest as any).resilience },
  ] : [];

  return (
    <div style={{ padding:'24px 28px', maxWidth:900 }}>

      {/* Usage banner — shows plan, usage, upgrade prompt */}
      <UsageBanner
        plan={tenant.plan_tier ?? 'free'}
        used={tenant.sessions_used_this_period ?? 0}
        limit={tenant.sessions_limit ?? 3}
        isAdmin={isAdmin}
        subStatus={tenant.sub_status}
        periodEnd={tenant.current_period_end}
      />

      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:22 }}>
        <div>
          <div style={{ fontSize:9, color:C.amber, letterSpacing:'.14em', fontFamily:'monospace', marginBottom:4 }}>REP DASHBOARD</div>
          <h1 style={{ fontSize:22, fontWeight:800, color:C.text }}>
            {userData?.full_name ? `Welcome back, ${userData.full_name.split(' ')[0]}` : 'Performance Center'}
          </h1>
        </div>
        <Link href="/session/new" style={{ padding:'9px 18px', background:C.amber, color:'#000', borderRadius:7, textDecoration:'none', fontSize:13, fontWeight:700 }}>
          🎙 Start Session
        </Link>
      </div>

      {/* Stats row */}
      <div style={{ display:'grid', gridTemplateColumns:'auto 1fr 1fr', gap:13, marginBottom:14 }}>
        {/* Readiness ring */}
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:9, padding:'18px 20px', display:'flex', alignItems:'center', gap:16, minWidth:185 }}>
          {latest ? (
            <>
              <ScoreRing value={(latest as any).readiness_score} size={78} />
              <div>
                <div style={{ fontSize:9, color:C.faint, letterSpacing:'.12em', fontFamily:'monospace', marginBottom:4 }}>READINESS</div>
                <div style={{ fontSize:15, fontWeight:800, color:C.text, marginBottom:2 }}>{sg((latest as any).readiness_score)}</div>
                <div style={{ fontSize:11, color:C.faint }}>L{(latest as any).diff ?? 2} · Latest</div>
              </div>
            </>
          ) : (
            <div style={{ textAlign:'center', width:'100%' }}>
              <div style={{ fontSize:9, color:C.faint, letterSpacing:'.12em', fontFamily:'monospace', marginBottom:8 }}>READINESS</div>
              <div style={{ fontSize:13, color:C.faint }}>No sessions yet</div>
            </div>
          )}
        </div>

        {/* Trend */}
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:9, padding:'18px 20px' }}>
          <div style={{ fontSize:9, color:C.faint, letterSpacing:'.12em', fontFamily:'monospace', marginBottom:6 }}>TREND</div>
          {trend !== null ? (
            <>
              <div style={{ fontSize:38, fontWeight:700, lineHeight:1, color:trend>=0?C.green:C.red, fontFamily:'monospace' }}>{trend>=0?'+':''}{trend}</div>
              <div style={{ fontSize:11, color:C.faint, marginTop:4 }}>vs previous session</div>
            </>
          ) : <div style={{ fontSize:13, color:C.faint, marginTop:8 }}>Complete 2+ sessions</div>}
        </div>

        {/* Sessions count */}
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:9, padding:'18px 20px' }}>
          <div style={{ fontSize:9, color:C.faint, letterSpacing:'.12em', fontFamily:'monospace', marginBottom:6 }}>SESSIONS</div>
          <div style={{ fontSize:38, fontWeight:700, lineHeight:1, fontFamily:'monospace' }}>{recentSessions?.length ?? 0}</div>
          <div style={{ fontSize:11, color:C.faint, marginTop:4 }}>all time</div>
        </div>
      </div>

      {/* Breakdown + history */}
      {latest && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:13, marginBottom:14 }}>
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:9, padding:'16px 18px' }}>
            <div style={{ fontSize:9, color:C.faint, letterSpacing:'.12em', fontFamily:'monospace', marginBottom:10 }}>SCORE BREAKDOWN</div>
            {dims.map(d => (
              <div key={d.label} style={{ marginBottom:10 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:3 }}>
                  <span style={{ fontSize:12, color:C.muted }}>{d.label} <span style={{ fontSize:9, color:C.faint, fontFamily:'monospace' }}>{d.w}</span></span>
                  <span style={{ fontSize:12, fontWeight:600, color:sc(d.v), fontFamily:'monospace' }}>{d.v}</span>
                </div>
                <div style={{ height:4, background:C.surface, borderRadius:2 }}>
                  <div style={{ height:'100%', width:`${Math.min(100,d.v)}%`, background:sc(d.v), borderRadius:2 }} />
                </div>
              </div>
            ))}
          </div>

          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:9, padding:'16px 18px' }}>
            <div style={{ fontSize:9, color:C.faint, letterSpacing:'.12em', fontFamily:'monospace', marginBottom:10 }}>RECENT SESSIONS</div>
            {recentSessions?.length ? (
              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead>
                  <tr>
                    {['DATE','DIFF','SCORE','OUTCOME'].map(h => (
                      <th key={h} style={{ fontSize:9, color:C.faint, letterSpacing:'.09em', fontFamily:'monospace', textAlign:'left', paddingBottom:7 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {recentSessions.slice(0,6).map(s => {
                    const score = scores?.find((sc: any) => (sc as any).session_id === s.id) as any;
                    return (
                      <tr key={s.id} style={{ borderTop:`1px solid ${C.border}` }}>
                        <td style={{ padding:'8px 4px 8px 0', fontSize:11, color:C.faint }}>{new Date(s.started_at).toLocaleDateString('en-US',{month:'short',day:'numeric'})}</td>
                        <td style={{ padding:'8px 4px' }}><span style={{ fontSize:9, fontFamily:'monospace', fontWeight:700, color:C.blue }}>L{s.difficulty}</span></td>
                        <td style={{ padding:'8px 4px' }}>
                          {score ? <span style={{ fontSize:14, fontWeight:700, color:sc(score.readiness_score), fontFamily:'monospace' }}>{score.readiness_score}</span> : <span style={{ fontSize:11, color:C.faint }}>—</span>}
                        </td>
                        <td style={{ padding:'8px 4px', fontSize:11, color:C.faint }}>{(s.outcome ?? s.status ?? '').replace(/_/g,' ')}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              <p style={{ fontSize:13, color:C.faint, textAlign:'center', marginTop:20 }}>Complete your first session</p>
            )}
          </div>
        </div>
      )}

      {!latest && (
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:9, padding:'40px 28px', textAlign:'center', marginBottom:14 }}>
          <div style={{ fontSize:28, marginBottom:12 }}>🎙</div>
          <h2 style={{ fontSize:18, fontWeight:700, color:C.text, marginBottom:8 }}>Ready to train?</h2>
          <p style={{ fontSize:13, color:C.muted, marginBottom:20 }}>Your first session starts your performance baseline. Hold-to-speak against a real AI homeowner.</p>
          <Link href="/session/new" style={{ padding:'11px 24px', background:C.amber, color:'#000', borderRadius:7, textDecoration:'none', fontSize:14, fontWeight:700 }}>
            Start First Session →
          </Link>
        </div>
      )}

      {/* Upgrade prompt for free tier */}
      {!isAdmin && (tenant.plan_tier === 'free' || !tenant.plan_tier) && (
        <div style={{ background:C.amberBg, border:`1px solid ${C.amber}30`, borderRadius:9, padding:'16px 20px', display:'flex', justifyContent:'space-between', alignItems:'center' } as any}>
          <div>
            <div style={{ fontSize:11, color:C.amber, fontFamily:'monospace', letterSpacing:'.1em', fontWeight:700, marginBottom:4 }}>FREE TIER · {tenant.sessions_used_this_period ?? 0}/3 SESSIONS USED</div>
            <div style={{ fontSize:13, color:C.muted }}>Upgrade to Starter ($19/mo) for 20 sessions/month + full access.</div>
          </div>
          <Link href="/pricing" style={{ padding:'8px 18px', background:C.amber, color:'#000', borderRadius:6, textDecoration:'none', fontSize:13, fontWeight:700, flexShrink:0 }}>
            Upgrade →
          </Link>
        </div>
      )}
    </div>
  );
}

// Inline score ring (server component safe — pure SVG)
function ScoreRing({ value, size }: { value: number; size: number }) {
  const r = size/2 - 6, circ = 2 * Math.PI * r;
  const fill = (value / 100) * circ;
  const color = value >= 72 ? C.green : value >= 50 ? C.amber : C.red;
  return (
    <div style={{ position:'relative', width:size, height:size, flexShrink:0 }}>
      <svg width={size} height={size} style={{ transform:'rotate(-90deg)', display:'block' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#ffffff08" strokeWidth={5} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={5}
          strokeDasharray={`${fill} ${circ - fill}`} strokeLinecap="round" />
      </svg>
      <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'monospace', fontWeight:700, fontSize:size*.23, color }}>
        {value}
      </div>
    </div>
  );
}

const C_amberBg = 'rgba(245,158,11,.1)';
