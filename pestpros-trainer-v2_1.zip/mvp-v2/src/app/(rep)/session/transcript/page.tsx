// src/app/(rep)/session/transcript/page.tsx
// Accessible by the rep who owns the session AND by managers/super_admins in the same tenant.
import { redirect } from 'next/navigation';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import Link from 'next/link';
import { COLORS } from '@/types';
import type { TranscriptRow } from '@/types';

export default async function TranscriptPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string }>;
}) {
  const sp = await searchParams;
  const id = sp.id;
  if (!id) redirect('/dashboard');

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  // Fetch the viewer's role and tenant so we can do the access check
  const { data: viewer } = await supabase
    .from('users').select('role, tenant_id').eq('id', user.id).single();
  if (!viewer) redirect('/login');

  const db = createServiceClient();
  const { data: session } = await db.from('sessions').select('*').eq('id', id).single();
  if (!session) redirect('/dashboard');

  const isOwner   = session.user_id === user.id;
  const isManager = ['manager', 'super_admin'].includes(viewer.role) &&
                    session.tenant_id === viewer.tenant_id;

  if (!isOwner && !isManager) redirect('/dashboard');

  const { data: rows } = await db
    .from('transcripts').select('*').eq('session_id', id).order('turn_index');
  const { data: score } = await db
    .from('scores').select('readiness_score, session_outcome').eq('session_id', id).single();

  // Determine the right back-link depending on who is viewing
  const backHref = isManager && !isOwner
    ? `/manager/rep?id=${session.user_id}`
    : `/session/results?id=${id}`;
  const backLabel = isManager && !isOwner ? '← Rep Detail' : '← Results';

  return (
    <div style={{ padding: '32px 36px', maxWidth: 700 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <h1 style={{ margin: '0 0 4px', fontSize: 20, fontWeight: 800, color: '#111827' }}>Transcript</h1>
          <p style={{ margin: 0, fontSize: 13, color: COLORS.gray }}>
            {new Date(session.created_at).toLocaleString()} · L{session.difficulty_level} · {session.turn_count} turns
            {score && ` · Score: ${score.readiness_score}`}
          </p>
        </div>
        <Link href={backHref} style={{ fontSize: 13, color: COLORS.gray, textDecoration: 'none' }}>{backLabel}</Link>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        {(rows as TranscriptRow[] ?? []).map(t => {
          const isRep = t.speaker === 'rep';
          return (
            <div key={t.id} style={{
              display: 'flex', gap: 10, padding: '12px 0',
              borderBottom: `1px solid ${COLORS.border}`,
              justifyContent: isRep ? 'flex-end' : 'flex-start',
            }}>
              {!isRep && (
                <div style={{ flexShrink: 0, width: 28, height: 28, borderRadius: '50%', background: '#F3F4F6', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, color: COLORS.gray, fontWeight: 700 }}>
                  {t.turn_index}
                </div>
              )}
              <div style={{ maxWidth: '72%' }}>
                <p style={{ margin: '0 0 3px', fontSize: 10, fontWeight: 700, color: isRep ? COLORS.steel : COLORS.gray, textTransform: 'uppercase', textAlign: isRep ? 'right' : 'left' }}>
                  {isRep ? 'You' : 'Homeowner'}
                </p>
                <div style={{
                  padding: '10px 14px', borderRadius: 10,
                  background: isRep ? '#EBF3FF' : '#F9FAFB',
                  fontSize: 14, color: '#1F2937', lineHeight: 1.5,
                }}>
                  {t.text}
                </div>
              </div>
              {isRep && (
                <div style={{ flexShrink: 0, width: 28, height: 28, borderRadius: '50%', background: '#EBF3FF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, color: COLORS.steel, fontWeight: 700 }}>
                  {t.turn_index}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
