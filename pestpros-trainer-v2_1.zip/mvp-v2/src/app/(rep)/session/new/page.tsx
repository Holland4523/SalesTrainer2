'use client';
// src/app/(rep)/session/new/page.tsx

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { DifficultyLevel } from '@/types';

const C = {
  bg:'#07090F', surface:'#0F1520', card:'#141E2E',
  amber:'#F59E0B', amberBg:'rgba(245,158,11,.1)',
  blue:'#3B82F6', green:'#10B981', red:'#EF4444',
  text:'#EFF6FF', muted:'rgba(239,246,255,.55)', faint:'rgba(239,246,255,.22)', border:'#ffffff0d',
};

const SCENARIOS = [
  { id:1, label:'Skeptical Homeowner',  personality:'skeptical', pest:'ants',       season:'spring', competitor:'Terminix' },
  { id:2, label:'Friendly but Hesitant',personality:'friendly',  pest:'spiders',    season:'summer', competitor:'none'    },
  { id:3, label:'Busy / Time-Pressured',personality:'busy',      pest:'rodents',    season:'fall',   competitor:'Orkin'   },
  { id:4, label:'Budget-Conscious',     personality:'frugal',    pest:'mosquitoes', season:'spring', competitor:'none'    },
];

const LEVELS = [
  { level:1 as DifficultyLevel, color:C.green, tag:'EASY',  desc:'Patient. Great for warm-up.' },
  { level:2 as DifficultyLevel, color:C.blue,  tag:'MED',   desc:'Some pushback. Real-world pacing.' },
  { level:3 as DifficultyLevel, color:C.amber, tag:'HARD',  desc:'Skeptical. Value framing required.' },
  { level:4 as DifficultyLevel, color:C.red,   tag:'ELITE', desc:'Will hang up if you stumble early.' },
];

export default function NewSessionPage() {
  const [difficulty, setDifficulty] = useState<DifficultyLevel>(2);
  const [scenario,   setScenario]   = useState(SCENARIOS[0]);
  const [micOk,      setMicOk]      = useState(false);
  const [micChecking,setMicChecking]= useState(false);
  const [starting,   setStarting]   = useState(false);
  const [error,      setError]      = useState('');
  const router = useRouter();

  async function checkMic() {
    setMicChecking(true);
    setError('');
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      s.getTracks().forEach(t => t.stop());
      setMicOk(true);
    } catch {
      setError('Microphone access denied. Allow mic in browser settings and try again.');
    } finally { setMicChecking(false); }
  }

  async function startSession() {
    if (!micOk) { setError('Check microphone first'); return; }
    setStarting(true);
    setError('');
    try {
      const res = await fetch('/api/session/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenarioType: scenario.personality,
          difficulty,
        }),
      });
      const data = await res.json();

      // ── BILLING BLOCKED ─────────────────────────────────────
      if (res.status === 402) {
        setError(data.error ?? 'Session limit reached');
        setStarting(false);
        return;
      }

      if (!res.ok) throw new Error(data.error ?? 'Failed to start session');
      router.push(`/session/active?id=${data.sessionId}`);
    } catch (err) {
      setError((err as Error).message);
      setStarting(false);
    }
  }

  const isLimited = error.includes('limit') || error.includes('Upgrade') || error.includes('subscription');

  return (
    <div style={{ padding:'24px 28px', maxWidth:560 }}>
      <button onClick={() => router.push('/dashboard')} style={backBtn}>← Back</button>

      <div style={{ fontSize:9, color:C.amber, letterSpacing:'.14em', fontFamily:'monospace', marginBottom:6 }}>NEW SESSION</div>
      <h1 style={{ fontSize:22, fontWeight:800, marginBottom:8, color:C.text }}>Configure Training</h1>
      <p style={{ fontSize:13, color:C.muted, marginBottom:24 }}>
        Voice-powered · GPT-4o-mini homeowner · Whisper transcription · OpenAI TTS
      </p>

      {/* Scenario */}
      <div style={{ fontSize:9, color:C.faint, letterSpacing:'.12em', fontFamily:'monospace', marginBottom:8 }}>HOMEOWNER TYPE</div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:22 }}>
        {SCENARIOS.map(s => (
          <div key={s.id} onClick={() => setScenario(s)} style={{
            padding:'11px 13px', borderRadius:7, cursor:'pointer',
            border:`1px solid ${scenario.id===s.id ? C.amber : C.border}`,
            background: scenario.id===s.id ? C.amberBg : C.card, transition:'all .15s',
          }}>
            <div style={{ fontSize:9, color:scenario.id===s.id?C.amber:C.faint, letterSpacing:'.1em', fontFamily:'monospace', marginBottom:4 }}>{s.personality.toUpperCase()}</div>
            <div style={{ fontSize:13, fontWeight:600, color:scenario.id===s.id?C.text:C.muted, marginBottom:2 }}>{s.label}</div>
            <div style={{ fontSize:11, color:C.faint }}>{s.pest} · {s.season}</div>
          </div>
        ))}
      </div>

      {/* Difficulty */}
      <div style={{ fontSize:9, color:C.faint, letterSpacing:'.12em', fontFamily:'monospace', marginBottom:8 }}>DIFFICULTY</div>
      <div style={{ display:'flex', gap:8, marginBottom:7 }}>
        {LEVELS.map(l => (
          <div key={l.level} onClick={() => setDifficulty(l.level)} style={{
            flex:1, padding:'10px 5px', borderRadius:7, cursor:'pointer', textAlign:'center',
            border:`1px solid ${difficulty===l.level ? l.color : C.border}`,
            background: difficulty===l.level ? l.color+'14' : C.card, transition:'all .15s',
          }}>
            <div style={{ fontSize:18, fontWeight:700, color:l.color, lineHeight:1, marginBottom:2, fontFamily:'monospace' }}>L{l.level}</div>
            <div style={{ fontSize:9, color:difficulty===l.level?l.color:C.faint, fontWeight:700, letterSpacing:'.08em' }}>{l.tag}</div>
          </div>
        ))}
      </div>
      <p style={{ fontSize:12, color:C.faint, marginBottom:22 }}>{LEVELS[difficulty-1].desc}</p>

      {/* Mic check */}
      <div style={{ padding:'12px 14px', background:C.card, border:`1px solid ${C.border}`, borderRadius:7, marginBottom:16, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ fontSize:12, fontWeight:600, color:C.text, marginBottom:2 }}>Microphone</div>
          <div style={{ fontSize:11, color:micOk ? C.green : C.faint }}>{micOk ? '✓ Ready' : 'Not checked yet'}</div>
        </div>
        <button onClick={checkMic} disabled={micOk || micChecking} style={{
          padding:'6px 14px', background:micOk?C.green+'20':'transparent',
          border:`1px solid ${micOk?C.green:C.border}`, borderRadius:5,
          color:micOk?C.green:C.muted, fontSize:12, fontWeight:600, cursor:micOk?'default':'pointer',
        }}>
          {micOk ? '✓ OK' : micChecking ? 'Checking…' : 'Check Mic'}
        </button>
      </div>

      {/* Errors */}
      {error && (
        <div style={{ padding:'11px 14px', background:isLimited?C.amberBg:'rgba(239,68,68,.08)', border:`1px solid ${isLimited?C.amber:C.red}30`, borderRadius:7, marginBottom:14 }}>
          <p style={{ fontSize:13, color:isLimited?C.amber:C.red, margin:0 }}>{error}</p>
          {isLimited && (
            <a href="/pricing" style={{ display:'inline-block', marginTop:8, padding:'5px 14px', background:C.amber, color:'#000', borderRadius:5, fontSize:12, fontWeight:700, textDecoration:'none' }}>
              View Plans →
            </a>
          )}
        </div>
      )}

      <button onClick={startSession} disabled={!micOk || starting} style={{
        width:'100%', padding:'12px', background: (!micOk||starting) ? C.card : C.amber,
        color: (!micOk||starting) ? C.faint : '#000',
        border:'none', borderRadius:7, fontSize:14, fontWeight:700,
        cursor: (!micOk||starting) ? 'not-allowed' : 'pointer', transition:'all .15s',
      }}>
        {starting ? 'Starting…' : '🎙 Go Live →'}
      </button>
      <p style={{ textAlign:'center', fontSize:11, color:C.faint, marginTop:9, fontFamily:'monospace' }}>
        🎧 USE HEADPHONES TO AVOID ECHO
      </p>
    </div>
  );
}

const backBtn: React.CSSProperties = {
  background:'none', border:'none', color:'rgba(239,246,255,.25)', fontSize:12,
  cursor:'pointer', marginBottom:18, padding:0,
};
