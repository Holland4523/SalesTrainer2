'use client';
// src/app/(rep)/session/results/page.tsx

import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useScorePolling } from '@/hooks/useScorePolling';
import { scoreColor, COLORS } from '@/types';

const DIMS = [
  { key: 'opener_score',             label: 'Opener',     weight: '22%' },
  { key: 'tonality_score',           label: 'Tonality',   weight: '18%' },
  { key: 'question_stack_score',     label: 'Discovery',  weight: '15%' },
  { key: 'objection_handling_score', label: 'Objections', weight: '25%' },
  { key: 'closing_score',            label: 'Closing',    weight: '10%' },
  { key: 'resilience_score',         label: 'Resilience', weight: '10%' },
];

// useSearchParams() must live inside a Suspense boundary in App Router.
function ResultsInner() {
  const searchParams = useSearchParams();
  const sessionId    = searchParams.get('id');
  const { score, weakAreas, isLoading, isError } = useScorePolling(sessionId);

  if (isLoading) {
    return (
      <div style={{ padding: '60px 36px', textAlign: 'center' }}>
        <p style={{ fontSize: 16, color: COLORS.gray, marginBottom: 8 }}>Scoring your session…</p>
        <div style={{ width: 200, height: 4, background: '#E5E7EB', borderRadius: 2, margin: '0 auto', overflow: 'hidden' }}>
          <div style={{ width: '60%', height: '100%', background: COLORS.steel, borderRadius: 2 }} />
        </div>
      </div>
    );
  }

  if (isError || !score) {
    return (
      <div style={{ padding: '60px 36px' }}>
        <p style={{ color: COLORS.red }}>Scoring failed or took too long. Try refreshing.</p>
        <Link href="/dashboard" style={{ color: COLORS.steel, fontSize: 14 }}>← Dashboard</Link>
      </div>
    );
  }

  return (
    <div style={{ padding: '32px 36px', maxWidth: 700 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: '#111827' }}>Session Results</h1>
        <Link href="/dashboard" style={{ fontSize: 13, color: COLORS.gray, textDecoration: 'none' }}>← Dashboard</Link>
      </div>

      {/* Readiness */}
      <div style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: '28px 32px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 28 }}>
        <div>
          <p style={{ margin: '0 0 4px', fontSize: 12, fontWeight: 700, color: COLORS.gray, textTransform: 'uppercase' }}>Readiness Score</p>
          <p style={{ margin: 0, fontSize: 64, fontWeight: 900, color: scoreColor(score.readiness_score), fontFamily: 'monospace', lineHeight: 1 }}>
            {score.readiness_score}
          </p>
        </div>
        <div>
          <p style={{ margin: '0 0 4px', fontSize: 12, color: COLORS.gray }}>Difficulty: L{score.difficulty_level}</p>
          <p style={{ margin: '0 0 4px', fontSize: 12, color: COLORS.gray }}>Outcome: {score.session_outcome ?? '—'}</p>
          <p style={{ margin: 0, fontSize: 11, color: '#D1D5DB', fontFamily: 'monospace' }}>
            Raw: {score.raw_readiness_score} × {score.difficulty_multiplier}
          </p>
        </div>
      </div>

      {/* Dimensions */}
      <div style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 24, marginBottom: 16 }}>
        <p style={{ margin: '0 0 16px', fontSize: 13, fontWeight: 700, color: '#374151' }}>Breakdown</p>
        {DIMS.map(({ key, label, weight }) => {
          const val = (score as Record<string, unknown>)[key] as number;
          return (
            <div key={key} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
                <span style={{ color: '#374151' }}>{label} <span style={{ color: COLORS.gray, fontSize: 11 }}>{weight}</span></span>
                <span style={{ fontWeight: 700, color: scoreColor(val), fontFamily: 'monospace' }}>{val}</span>
              </div>
              <div style={{ height: 8, background: '#F3F4F6', borderRadius: 4 }}>
                <div style={{ width: `${val}%`, height: '100%', background: scoreColor(val), borderRadius: 4 }} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Weak areas + coaching */}
      {weakAreas.length > 0 && (
        <div style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 24, marginBottom: 16 }}>
          <p style={{ margin: '0 0 14px', fontSize: 13, fontWeight: 700, color: '#374151' }}>Coaching Recommendations</p>
          {weakAreas.map(wa => (
            <div key={wa.id} style={{ marginBottom: 12, padding: '10px 12px', background: '#FFFBEB', borderRadius: 8, borderLeft: `3px solid ${COLORS.amber}` }}>
              <p style={{ margin: '0 0 4px', fontSize: 12, fontWeight: 700, color: COLORS.amber }}>{wa.tag.replace(/_/g, ' ')}</p>
              <p style={{ margin: 0, fontSize: 13, color: '#374151', lineHeight: 1.5 }}>{wa.recommendation}</p>
            </div>
          ))}
        </div>
      )}

      {/* Scoring notes */}
      {score.scoring_notes && (
        <div style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 20, marginBottom: 20 }}>
          <p style={{ margin: '0 0 8px', fontSize: 12, fontWeight: 700, color: COLORS.gray, textTransform: 'uppercase' }}>Notes</p>
          <p style={{ margin: 0, fontSize: 13, color: '#374151', lineHeight: 1.6 }}>{score.scoring_notes}</p>
        </div>
      )}

      <div style={{ display: 'flex', gap: 12 }}>
        <Link href="/session/new" style={{
          flex: 1, padding: '12px', background: COLORS.navy, color: '#fff',
          borderRadius: 8, textDecoration: 'none', textAlign: 'center', fontSize: 14, fontWeight: 700,
        }}>
          Practice Again
        </Link>
        <Link href={`/session/transcript?id=${sessionId}`} style={{
          flex: 1, padding: '12px', background: '#fff', color: '#374151',
          border: `1px solid ${COLORS.border}`, borderRadius: 8, textDecoration: 'none',
          textAlign: 'center', fontSize: 14, fontWeight: 600,
        }}>
          View Transcript
        </Link>
      </div>
    </div>
  );
}

export default function ResultsPage() {
  return (
    <Suspense fallback={
      <div style={{ padding: '60px 36px', textAlign: 'center' }}>
        <p style={{ fontSize: 16, color: COLORS.gray }}>Loading…</p>
      </div>
    }>
      <ResultsInner />
    </Suspense>
  );
}
