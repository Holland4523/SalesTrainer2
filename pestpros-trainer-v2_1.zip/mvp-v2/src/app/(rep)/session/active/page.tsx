'use client';
// src/app/(rep)/session/active/page.tsx

import { Suspense, useState, useEffect, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useVoiceSession } from '@/hooks/useVoiceSession';
import { COLORS } from '@/types';

// useSearchParams must be inside a Suspense boundary in App Router.
// Split into inner component + Suspense wrapper at the export.

function ActiveSessionInner() {
  const searchParams = useSearchParams();
  const sessionId    = searchParams.get('id') ?? '';
  const router       = useRouter();

  const [messages,     setMessages]     = useState<Array<{ speaker: 'rep'|'ai'; text: string }>>([]);
  const [sessionEnded, setSessionEnded] = useState(false);
  const [endConfirm,   setEndConfirm]   = useState(false);
  const [turnCount,    setTurnCount]    = useState(0);
  const [error,        setError]        = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sessionId) { router.push('/session/new'); return; }

    fetch(`/api/session/transcript?id=${sessionId}`)
      .then(r => r.json())
      .then(d => {
        if (d.rows?.length) {
          setMessages(d.rows.map((r: { speaker: string; text: string }) => ({
            speaker: r.speaker as 'rep'|'ai', text: r.text,
          })));
        }
      })
      .catch(() => {});
  }, [sessionId, router]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const { voiceState, transcript, interim, isSupported, startListening, stopListening, skipSpeech } =
    useVoiceSession({
      sessionId,
      onTurnComplete: (reply, ended, reason) => {
        setMessages(prev => [...prev, { speaker: 'ai', text: reply }]);
        setTurnCount(n => n + 1);
        if (ended) {
          setSessionEnded(true);
          setTimeout(() => router.push(`/session/results?id=${sessionId}`), 2000);
        }
      },
      onError: setError,
    });

  function handleStopListening() {
    if (transcript.trim()) {
      setMessages(prev => [...prev, { speaker: 'rep', text: transcript }]);
    }
    stopListening();
  }

  async function handleEndSession() {
    if (!endConfirm) { setEndConfirm(true); return; }
    await fetch('/api/session/end', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId }),
    });
    router.push(`/session/results?id=${sessionId}`);
  }

  if (!isSupported) {
    return (
      <div style={{ minHeight: '100vh', background: '#111827', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', color: '#fff' }}>
          <p style={{ fontSize: 18, fontWeight: 700 }}>Browser Not Supported</p>
          <p style={{ color: '#9CA3AF' }}>Use Chrome or Edge for voice sessions.</p>
        </div>
      </div>
    );
  }

  const isListening  = voiceState === 'listening';
  const isProcessing = voiceState === 'processing' || voiceState === 'speaking';

  return (
    <div style={{
      position: 'fixed', inset: 0, background: '#0F172A',
      display: 'flex', flexDirection: 'column', fontFamily: 'system-ui, sans-serif',
    }}>
      {/* Header */}
      <div style={{ padding: '12px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: COLORS.amber, letterSpacing: '0.1em' }}>LIVE</span>
          <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>Turn {turnCount} / 20</span>
          {turnCount >= 15 && (
            <span style={{ fontSize: 12, color: COLORS.red, fontWeight: 700 }}>⚠ {20 - turnCount} turns left</span>
          )}
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {voiceState === 'speaking' && (
            <button onClick={skipSpeech} style={ghostBtn}>Skip ▶▶</button>
          )}
          <button
            onClick={handleEndSession}
            style={{ ...ghostBtn, color: endConfirm ? COLORS.red : 'rgba(255,255,255,0.5)' }}
          >
            {endConfirm ? 'Confirm End' : 'End Session'}
          </button>
        </div>
      </div>

      {/* Transcript */}
      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: '20px 28px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ maxWidth: '75%', alignSelf: m.speaker === 'rep' ? 'flex-end' : 'flex-start' }}>
            <p style={{ margin: '0 0 3px', fontSize: 10, fontWeight: 700, color: 'rgba(255,255,255,0.3)', textTransform: 'uppercase', textAlign: m.speaker === 'rep' ? 'right' : 'left' }}>
              {m.speaker === 'rep' ? 'You' : 'Homeowner'}
            </p>
            <div style={{
              padding: '10px 14px', borderRadius: 12,
              background: m.speaker === 'rep' ? COLORS.steel : 'rgba(255,255,255,0.08)',
              color: '#fff', fontSize: 14, lineHeight: 1.5,
            }}>
              {m.text}
            </div>
          </div>
        ))}

        {isListening && interim && (
          <div style={{ alignSelf: 'flex-end', maxWidth: '75%' }}>
            <div style={{ padding: '10px 14px', borderRadius: 12, background: 'rgba(46,91,168,0.4)', color: 'rgba(255,255,255,0.6)', fontSize: 14, fontStyle: 'italic' }}>
              {interim}
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div style={{ padding: '20px 28px', borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
        {error && <p style={{ margin: 0, color: COLORS.red, fontSize: 13 }}>{error}</p>}

        {sessionEnded ? (
          <p style={{ color: COLORS.green, fontSize: 16, fontWeight: 700 }}>Session complete — redirecting…</p>
        ) : (
          <>
            <button
              onPointerDown={startListening}
              onPointerUp={handleStopListening}
              disabled={isProcessing}
              style={{
                width: 80, height: 80, borderRadius: '50%', border: 'none',
                cursor: isProcessing ? 'not-allowed' : 'pointer',
                background: isListening ? COLORS.red : isProcessing ? 'rgba(255,255,255,0.1)' : COLORS.steel,
                transition: 'all 0.15s',
                boxShadow: isListening ? '0 0 0 12px rgba(192,57,43,0.3)' : 'none',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 28,
              }}
            >
              {isProcessing ? '…' : isListening ? '🔴' : '🎙'}
            </button>
            <p style={{ margin: 0, fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>
              {isListening ? 'Release to send' : isProcessing ? 'Processing…' : 'Hold to speak'}
            </p>
          </>
        )}
      </div>
    </div>
  );
}

export default function ActiveSessionPage() {
  return (
    <Suspense fallback={
      <div style={{ minHeight: '100vh', background: '#0F172A', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>Loading session…</p>
      </div>
    }>
      <ActiveSessionInner />
    </Suspense>
  );
}

const ghostBtn: React.CSSProperties = {
  padding: '6px 12px', background: 'transparent',
  border: '1px solid rgba(255,255,255,0.15)', borderRadius: 6,
  color: 'rgba(255,255,255,0.5)', cursor: 'pointer', fontSize: 12,
};
