// src/app/(rep)/layout.tsx
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import Link from 'next/link';
import { COLORS } from '@/types';

export default async function RepLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      {/* Sidebar */}
      <aside style={{
        width: 220, background: COLORS.navy, color: '#fff',
        display: 'flex', flexDirection: 'column', padding: '20px 0', flexShrink: 0,
      }}>
        <div style={{ padding: '0 20px 20px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
          <p style={{ margin: 0, fontSize: 11, fontWeight: 700, color: COLORS.amber, letterSpacing: '0.1em' }}>
            SALES TRAINER
          </p>
        </div>
        <nav style={{ padding: '16px 12px', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {[
            { href: '/dashboard',      label: '📊 Dashboard' },
            { href: '/session/new',    label: '🎙 Start Session' },
          ].map(({ href, label }) => (
            <Link key={href} href={href} style={{
              display: 'block', padding: '9px 12px', borderRadius: 8,
              color: 'rgba(255,255,255,0.8)', textDecoration: 'none', fontSize: 14,
            }}>
              {label}
            </Link>
          ))}
        </nav>
      </aside>
      <main style={{ flex: 1, overflow: 'auto' }}>{children}</main>
    </div>
  );
}
