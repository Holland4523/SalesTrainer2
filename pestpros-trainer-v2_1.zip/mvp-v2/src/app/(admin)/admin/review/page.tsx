// src/app/(admin)/admin/review/page.tsx
import { createClient, createServiceClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { scoreColor, COLORS } from '@/types';
import type { ReviewStatus } from '@/types';

const STATUS_STYLES: Record<ReviewStatus, { bg: string; color: string }> = {
  pending_review:   { bg: '#F3F4F6', color: '#6B7280' },
  approved:         { bg: '#E8F5EE', color: '#1E7E4A' },
  needs_adjustment: { bg: '#FDECEA', color: '#C0392B' },
  re_scored:        { bg: '#EBF3FF', color: '#2E5BA8' },
};

const STATUS_LABELS: Record<ReviewStatus, string> = {
  pending_review:   'Pending',
  approved:         'Approved',
  needs_adjustment: 'Needs Adj.',
  re_scored:        'Re-Scored',
};

export default async function ReviewQueuePage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const db = createServiceClient();

  let query = db
    .from('scores')
    .select(`
      id, readiness_score, difficulty_level, session_outcome,
      review_status, reviewed_at, scoring_prompt_version, created_at,
      sessions!inner(turn_count, ended_at),
      users!user_id(email, full_name)
    `)
    .order('created_at', { ascending: true });

  if (sp.status) query = query.eq('review_status', sp.status);

  const { data: rows } = await query;

  // Gate metrics: sessions with corrections
  const { data: allScores } = await db
    .from('scores')
    .select('review_status, corrected_readiness_score, readiness_score')
    .not('review_status', 'eq', 'pending_review');

  const reviewed    = (allScores ?? []).filter(s => s.review_status !== 'pending_review');
  const approved    = reviewed.filter(s => s.review_status === 'approved').length;
  const needsAdj    = reviewed.filter(s => s.review_status === 'needs_adjustment').length;
  const withDeltas  = reviewed.filter(s => s.corrected_readiness_score != null);
  const avgDelta    = withDeltas.length
    ? withDeltas.reduce((sum, s) => sum + Math.abs((s.corrected_readiness_score as number) - (s.readiness_score as number)), 0) / withDeltas.length
    : null;
  const pending     = (rows ?? []).filter(r => r.review_status === 'pending_review').length;

  const gateReady = reviewed.length >= 15 && needsAdj === 0 && (avgDelta === null || avgDelta <= 12);

  return (
    <div style={{ padding: '28px 32px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h1 style={{ margin: 0, fontSize: 20, fontWeight: 800, color: '#111827' }}>Score Review Queue</h1>
        <Link href="/admin" style={{ fontSize: 13, color: COLORS.gray, textDecoration: 'none' }}>← Admin</Link>
      </div>

      {/* Gate banner */}
      <div style={{
        background: gateReady ? '#E8F5EE' : pending > 0 ? '#FFFBEB' : '#FDECEA',
        border: `1px solid ${gateReady ? '#B8DEC8' : pending > 0 ? '#FCD34D' : '#FCA5A5'}`,
        borderRadius: 10, padding: '14px 18px', marginBottom: 20,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <p style={{ margin: '0 0 3px', fontSize: 13, fontWeight: 700, color: gateReady ? COLORS.green : COLORS.amber }}>
              {gateReady ? '✓ Alpha Gate: Ready to activate' : `⏳ Alpha Gate: ${pending} pending`}
            </p>
            <p style={{ margin: 0, fontSize: 12, color: '#374151' }}>
              {reviewed.length} reviewed · {approved} approved · {needsAdj} need adjustment
            </p>
            {gateReady && (
              <p style={{ margin: '6px 0 0', fontSize: 11, fontFamily: 'monospace', color: COLORS.green }}>
                UPDATE scoring_prompt_versions SET is_active = true WHERE version = 'v1.0';
              </p>
            )}
          </div>
          <div style={{ display: 'flex', gap: 20 }}>
            <div style={{ textAlign: 'center' }}>
              <p style={{ margin: 0, fontFamily: 'monospace', fontWeight: 700, fontSize: 18, color: avgDelta !== null && avgDelta > 12 ? COLORS.red : COLORS.green }}>
                {avgDelta !== null ? `±${avgDelta.toFixed(1)}` : '—'}
              </p>
              <p style={{ margin: 0, fontSize: 10, color: COLORS.gray }}>Avg Δ (≤12)</p>
            </div>
            <div style={{ textAlign: 'center' }}>
              <p style={{ margin: 0, fontFamily: 'monospace', fontWeight: 700, fontSize: 18, color: reviewed.length >= 15 ? COLORS.green : COLORS.amber }}>
                {reviewed.length}
              </p>
              <p style={{ margin: 0, fontSize: 10, color: COLORS.gray }}>Reviewed (≥15)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
        {([undefined, 'pending_review', 'approved', 'needs_adjustment', 're_scored'] as const).map(s => {
          const active = (sp.status ?? undefined) === s;
          return (
            <Link
              key={s ?? 'all'}
              href={s ? `?status=${s}` : '/admin/review'}
              style={{
                padding: '5px 12px', borderRadius: 6, fontSize: 12, textDecoration: 'none',
                fontWeight: active ? 700 : 400,
                background: active ? COLORS.navy : '#fff',
                color:      active ? '#fff' : COLORS.gray,
                border:     `1px solid ${active ? COLORS.navy : COLORS.border}`,
              }}
            >
              {s ? STATUS_LABELS[s as ReviewStatus] : 'All'}
            </Link>
          );
        })}
      </div>

      {/* Table */}
      <div style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 10, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: COLORS.bg, borderBottom: `1px solid ${COLORS.border}` }}>
              {['#','Status','Score','Difficulty','Turns','Outcome','Scored',''].map(h => (
                <th key={h} style={{ padding: '9px 14px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: COLORS.gray, textTransform: 'uppercase' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {!(rows?.length) ? (
              <tr><td colSpan={8} style={{ padding: '24px 14px', color: COLORS.gray, textAlign: 'center' }}>No sessions found.</td></tr>
            ) : rows.map((r, i) => {
              const st = r.review_status as ReviewStatus;
              const sc = STATUS_STYLES[st] ?? STATUS_STYLES.pending_review;
              const session = r.sessions as Record<string, unknown>;
              return (
                <tr key={r.id} style={{ borderTop: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: '10px 14px', color: COLORS.gray, fontFamily: 'monospace' }}>{i + 1}</td>
                  <td style={{ padding: '10px 14px' }}>
                    <span style={{ padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 700, background: sc.bg, color: sc.color }}>
                      {STATUS_LABELS[st]}
                    </span>
                  </td>
                  <td style={{ padding: '10px 14px', fontFamily: 'monospace', fontWeight: 700, color: scoreColor(r.readiness_score) }}>
                    {r.readiness_score}
                  </td>
                  <td style={{ padding: '10px 14px', color: COLORS.gray }}>L{r.difficulty_level}</td>
                  <td style={{ padding: '10px 14px', color: COLORS.gray, fontFamily: 'monospace' }}>
                    {(session?.turn_count as number) ?? '—'}
                  </td>
                  <td style={{ padding: '10px 14px', color: COLORS.gray }}>{r.session_outcome ?? '—'}</td>
                  <td style={{ padding: '10px 14px', color: COLORS.gray, whiteSpace: 'nowrap' }}>
                    {new Date(r.created_at).toLocaleDateString()}
                  </td>
                  <td style={{ padding: '10px 14px' }}>
                    <Link href={`/admin/review/${r.id}`} style={{ color: COLORS.steel, fontSize: 12, fontWeight: 600, textDecoration: 'none' }}>
                      {st === 'pending_review' || st === 're_scored' ? 'Review →' : 'View →'}
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
