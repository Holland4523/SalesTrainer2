'use client';
// src/app/(admin)/admin/review/[scoreId]/page.tsx

import { use, useEffect, useState } from 'react';
import Link from 'next/link';
import { scoreColor, COLORS } from '@/types';
import type { Score, WeakArea, Session, TranscriptRow, ReviewSubmitRequest, ReviewStatus } from '@/types';

interface ReviewBundle {
  score:      Score;
  session:    Session;
  transcript: TranscriptRow[];
  weakAreas:  WeakArea[];
  rep:        { email: string; full_name: string | null } | null;
}

const DIMS = [
  { key: 'opener_score',             label: 'Opener',     weight: '22%' },
  { key: 'tonality_score',           label: 'Tonality',   weight: '18%' },
  { key: 'question_stack_score',     label: 'Discovery',  weight: '15%' },
  { key: 'objection_handling_score', label: 'Objections', weight: '25%' },
  { key: 'closing_score',            label: 'Closing',    weight: '10%' },
  { key: 'resilience_score',         label: 'Resilience', weight: '10%' },
] as const;

const CORR_KEY: Record<string, keyof ReviewSubmitRequest> = {
  opener_score:             'corrected_opener_score',
  tonality_score:           'corrected_tonality_score',
  question_stack_score:     'corrected_question_stack_score',
  objection_handling_score: 'corrected_objection_handling_score',
  closing_score:            'corrected_closing_score',
  resilience_score:         'corrected_resilience_score',
};

const STATUS_COLORS: Record<ReviewStatus, { bg: string; color: string }> = {
  pending_review:   { bg: '#F3F4F6', color: '#6B7280' },
  approved:         { bg: '#E8F5EE', color: '#1E7E4A' },
  needs_adjustment: { bg: '#FDECEA', color: '#C0392B' },
  re_scored:        { bg: '#EBF3FF', color: '#2E5BA8' },
};

export default function ReviewDetailPage({ params }: { params: Promise<{ scoreId: string }> }) {
  const { scoreId } = use(params);

  const [bundle,     setBundle]     = useState<ReviewBundle | null>(null);
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [saved,      setSaved]      = useState(false);

  // Form state
  const [outcome,       setOutcome]       = useState<'approved' | 'needs_adjustment' | null>(null);
  const [notes,         setNotes]         = useState('');
  const [corrReadiness, setCorrReadiness] = useState('');
  const [corrDims,      setCorrDims]      = useState<Record<string, string>>({});

  useEffect(() => {
    fetch(`/api/admin/review/${scoreId}`)
      .then(r => r.json())
      .then((d: ReviewBundle & { error?: string }) => {
        if (d.error) { setError(d.error); return; }
        setBundle(d);
        // Prefill existing review
        if (d.score.review_status !== 'pending_review') {
          setOutcome(d.score.score_approved ? 'approved' : d.score.score_adjustment_needed ? 'needs_adjustment' : null);
          setNotes(d.score.reviewer_notes ?? '');
          if (d.score.corrected_readiness_score != null) {
            setCorrReadiness(String(d.score.corrected_readiness_score));
          }
          const dims: Record<string, string> = {};
          for (const { key } of DIMS) {
            const ck = CORR_KEY[key] as keyof Score;
            const v  = d.score[ck] as number | null;
            if (v != null) dims[key] = String(v);
          }
          setCorrDims(dims);
          setSaved(true);
        }
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [scoreId]);

  async function submit() {
    if (!outcome) { alert('Select Approved or Needs Adjustment.'); return; }
    if (outcome === 'needs_adjustment' && !notes.trim()) {
      alert('Reviewer notes required when marking Needs Adjustment.'); return;
    }
    setSubmitting(true);

    const payload: ReviewSubmitRequest = {
      scoreId,
      outcome,
      reviewer_notes: notes,
      corrected_readiness_score: corrReadiness ? parseFloat(corrReadiness) : undefined,
    };
    for (const { key } of DIMS) {
      const v = corrDims[key];
      if (v) (payload as Record<string, unknown>)[CORR_KEY[key]] = parseFloat(v);
    }

    const res = await fetch('/api/admin/review', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    setSubmitting(false);
    if (res.ok) { setSaved(true); }
    else { const d = await res.json(); alert(d.error ?? 'Save failed'); }
  }

  if (loading) return <Spinner />;
  if (error || !bundle) return <ErrorView msg={error || 'Not found'} />;

  const { score, session, transcript, weakAreas, rep } = bundle;
  const st = score.review_status;
  const sc = STATUS_COLORS[st];
  const delta = corrReadiness ? Math.abs(parseFloat(corrReadiness) - score.readiness_score) : null;

  return (
    <div style={{ minHeight: '100vh', background: COLORS.bg, fontFamily: 'system-ui, sans-serif' }}>

      {/* Header */}
      <div style={{
        background: COLORS.navy, padding: '12px 24px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <Link href="/admin/review" style={{ color: 'rgba(255,255,255,0.5)', fontSize: 13, textDecoration: 'none' }}>← Queue</Link>
          <span style={{ color: 'rgba(255,255,255,0.2)' }}>|</span>
          <span style={{ fontSize: 14, fontWeight: 600, color: '#fff' }}>Score Review</span>
          <span style={{ padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 700, background: sc.bg, color: sc.color }}>
            {st.replace(/_/g, ' ')}
          </span>
        </div>
        <span style={{ fontSize: 11, fontFamily: 'monospace', color: 'rgba(255,255,255,0.3)' }}>
          {rep?.email ?? score.user_id.slice(0, 8)}
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '420px 1fr', minHeight: 'calc(100vh - 48px)' }}>

        {/* LEFT — Score + Form */}
        <div style={{ background: '#fff', borderRight: `1px solid ${COLORS.border}`, overflowY: 'auto', padding: '22px 22px 40px' }}>

          {/* Session meta */}
          <Sec title="Session">
            <Row label="Rep"       value={rep?.full_name ?? rep?.email ?? '—'} />
            <Row label="Date"      value={new Date(session.created_at).toLocaleString()} />
            <Row label="Difficulty" value={`Level ${session.difficulty_level}`} />
            <Row label="Turns"     value={`${session.turn_count} / ${session.max_turns}`} />
            <Row label="Outcome"   value={session.session_outcome ?? '—'} />
            <Row label="Ended"     value={session.termination_reason ?? '—'} />
            <Row label="Quality"   value={session.session_quality ?? '—'} />
          </Sec>

          {/* Readiness */}
          <Sec title="Readiness Score">
            <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 14 }}>
              <span style={{ fontSize: 52, fontWeight: 900, color: scoreColor(score.readiness_score), fontFamily: 'monospace', lineHeight: 1 }}>
                {score.readiness_score}
              </span>
              <div>
                <p style={{ margin: '0 0 2px', fontSize: 12, color: COLORS.gray }}>Model output</p>
                <p style={{ margin: 0, fontSize: 11, color: '#D1D5DB', fontFamily: 'monospace' }}>
                  {score.raw_readiness_score} × {score.difficulty_multiplier}
                </p>
              </div>
            </div>
            <label style={lblStyle}>Corrected Score (optional)</label>
            <input
              type="number" min="0" max="100" step="0.5"
              value={corrReadiness}
              onChange={e => setCorrReadiness(e.target.value)}
              placeholder={String(score.readiness_score)}
              style={{ ...inputStyle, borderColor: delta !== null && delta > 12 ? COLORS.red : COLORS.border }}
            />
            {delta !== null && (
              <p style={{ margin: '4px 0 0', fontSize: 12, fontWeight: 600, color: delta > 12 ? COLORS.red : COLORS.green }}>
                Δ {delta.toFixed(1)} pts {delta > 12 ? '⚠ exceeds ±12 threshold' : '✓'}
              </p>
            )}
          </Sec>

          {/* Dimension breakdown */}
          <Sec title="Dimensions">
            {DIMS.map(({ key, label, weight }) => {
              const val  = (score as Record<string, unknown>)[key] as number;
              const corrVal = corrDims[key] ?? '';
              return (
                <div key={key} style={{ marginBottom: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 3 }}>
                    <span style={{ color: '#374151' }}>{label} <span style={{ color: COLORS.gray }}>{weight}</span></span>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontFamily: 'monospace', fontWeight: 700, color: scoreColor(val) }}>{val}</span>
                      <input
                        type="number" min="0" max="100"
                        value={corrVal}
                        onChange={e => setCorrDims(p => ({ ...p, [key]: e.target.value }))}
                        placeholder="—"
                        style={{ width: 52, padding: '2px 6px', border: `1px solid ${COLORS.border}`, borderRadius: 4, fontSize: 12, fontFamily: 'monospace', textAlign: 'right' }}
                      />
                    </div>
                  </div>
                  <div style={{ height: 5, background: '#F3F4F6', borderRadius: 3 }}>
                    <div style={{ width: `${val}%`, height: '100%', background: scoreColor(val), borderRadius: 3 }} />
                  </div>
                </div>
              );
            })}
          </Sec>

          {/* Weak areas */}
          {weakAreas.length > 0 && (
            <Sec title="Weak Areas">
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: 10 }}>
                {weakAreas.map(wa => (
                  <span key={wa.id} style={{ padding: '2px 8px', background: '#FEF3DC', color: COLORS.amber, borderRadius: 4, fontSize: 11, fontWeight: 600 }}>
                    {wa.tag.replace(/_/g, ' ')}
                  </span>
                ))}
              </div>
              {weakAreas.map(wa => (
                <div key={wa.id} style={{ marginBottom: 8, padding: '6px 10px', background: COLORS.bg, borderRadius: 6 }}>
                  <p style={{ margin: '0 0 2px', fontSize: 11, fontWeight: 700, color: COLORS.amber }}>{wa.tag}</p>
                  <p style={{ margin: 0, fontSize: 12, color: '#374151', lineHeight: 1.4 }}>{wa.recommendation}</p>
                </div>
              ))}
            </Sec>
          )}

          {/* Scenario */}
          {session.scenario_object && (
            <Sec title="Scenario">
              {Object.entries(session.scenario_object as Record<string, string>).map(([k, v]) => (
                <Row key={k} label={k.replace(/_/g, ' ')} value={String(v)} />
              ))}
            </Sec>
          )}

          {/* Review form */}
          <Sec title="Review Decision">
            {saved && (
              <div style={{ padding: '8px 12px', background: '#E8F5EE', border: '1px solid #B8DEC8', borderRadius: 6, marginBottom: 12 }}>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: COLORS.green }}>✓ Review saved</p>
              </div>
            )}
            <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
              {(['approved', 'needs_adjustment'] as const).map(o => (
                <button
                  key={o}
                  onClick={() => setOutcome(o)}
                  style={{
                    flex: 1, padding: '10px', borderRadius: 8, cursor: 'pointer', fontWeight: 700, fontSize: 13,
                    border: `2px solid ${outcome === o ? (o === 'approved' ? COLORS.green : COLORS.red) : COLORS.border}`,
                    background: outcome === o ? (o === 'approved' ? '#E8F5EE' : '#FDECEA') : '#fff',
                    color: outcome === o ? (o === 'approved' ? COLORS.green : COLORS.red) : COLORS.gray,
                  }}
                >
                  {o === 'approved' ? '✓ Approve' : '✗ Needs Adjustment'}
                </button>
              ))}
            </div>
            <label style={lblStyle}>
              Reviewer Notes {outcome === 'needs_adjustment' && <span style={{ color: COLORS.red }}>*required</span>}
            </label>
            <textarea
              rows={5} value={notes} onChange={e => setNotes(e.target.value)}
              placeholder="What did the model get wrong? What should the correct score be? What needs to change in the prompt?"
              style={{ ...inputStyle, resize: 'vertical', fontFamily: 'system-ui', lineHeight: 1.5 }}
            />
            <button
              onClick={submit} disabled={submitting || !outcome}
              style={{
                marginTop: 14, width: '100%', padding: '12px', borderRadius: 8,
                background: !outcome ? '#F3F4F6' : COLORS.navy,
                color: !outcome ? COLORS.gray : '#fff',
                border: 'none', cursor: !outcome ? 'not-allowed' : 'pointer',
                fontWeight: 700, fontSize: 14,
              }}
            >
              {submitting ? 'Saving…' : saved ? 'Update Review' : 'Submit Review'}
            </button>
          </Sec>
        </div>

        {/* RIGHT — Transcript */}
        <div style={{ overflowY: 'auto', padding: '22px 28px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: '#111827' }}>
              Transcript
              <span style={{ marginLeft: 8, fontSize: 13, fontWeight: 400, color: COLORS.gray }}>
                {transcript.length} turns
              </span>
            </h2>
          </div>
          {transcript.length === 0
            ? <p style={{ color: COLORS.gray }}>No transcript.</p>
            : transcript.map(t => {
                const isRep = t.speaker === 'rep';
                return (
                  <div key={t.id} style={{
                    display: 'flex', gap: 10, padding: '11px 0',
                    borderBottom: `1px solid ${COLORS.border}`,
                    alignItems: 'flex-start',
                  }}>
                    <div style={{
                      flexShrink: 0, width: 24, height: 24, borderRadius: '50%',
                      background: isRep ? '#EBF3FF' : '#F3F4F6',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 10, fontWeight: 700, color: isRep ? COLORS.steel : COLORS.gray,
                    }}>
                      {t.turn_index}
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{ margin: '0 0 3px', fontSize: 10, fontWeight: 700, textTransform: 'uppercase', color: isRep ? COLORS.steel : COLORS.gray, letterSpacing: '0.06em' }}>
                        {isRep ? 'Rep' : 'Homeowner'}
                      </p>
                      <p style={{ margin: 0, fontSize: 14, color: '#1F2937', lineHeight: 1.55 }}>{t.text}</p>
                    </div>
                  </div>
                );
              })
          }
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tiny helpers
// ---------------------------------------------------------------------------

function Sec({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <p style={{ margin: '0 0 10px', fontSize: 11, fontWeight: 700, color: COLORS.gray, textTransform: 'uppercase', letterSpacing: '0.08em', borderBottom: `1px solid ${COLORS.border}`, paddingBottom: 6 }}>
        {title}
      </p>
      {children}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: `1px solid ${COLORS.bg}`, fontSize: 13 }}>
      <span style={{ color: COLORS.gray }}>{label}</span>
      <span style={{ color: '#374151', fontWeight: 500 }}>{value}</span>
    </div>
  );
}

function Spinner() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: COLORS.bg }}>
      <p style={{ color: COLORS.gray }}>Loading…</p>
    </div>
  );
}

function ErrorView({ msg }: { msg: string }) {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
      <p style={{ color: COLORS.red, fontWeight: 700 }}>{msg}</p>
      <Link href="/admin/review" style={{ color: COLORS.steel, fontSize: 14 }}>← Back to queue</Link>
    </div>
  );
}

const lblStyle: React.CSSProperties = {
  display: 'block', fontSize: 12, fontWeight: 600, color: '#374151', marginBottom: 5,
};
const inputStyle: React.CSSProperties = {
  width: '100%', padding: '8px 10px', border: `1px solid ${COLORS.border}`,
  borderRadius: 6, fontSize: 13, boxSizing: 'border-box',
};
