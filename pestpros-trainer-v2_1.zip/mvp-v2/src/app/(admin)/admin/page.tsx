// src/app/(admin)/admin/page.tsx
import { createClient, createServiceClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { COLORS } from '@/types';

export default async function AdminPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const db = createServiceClient();

  const [
    { count: totalSessions },
    { count: pendingReview  },
    { count: totalReps      },
  ] = await Promise.all([
    db.from('sessions').select('id', { count: 'exact', head: true }),
    db.from('scores').select('id', { count: 'exact', head: true }).eq('review_status', 'pending_review'),
    db.from('users').select('id', { count: 'exact', head: true }).eq('role', 'rep'),
  ]);

  const stats = [
    { label: 'Total Sessions',  value: totalSessions ?? 0, color: COLORS.navy  },
    { label: 'Pending Review',  value: pendingReview  ?? 0, color: COLORS.amber },
    { label: 'Active Reps',     value: totalReps      ?? 0, color: COLORS.green },
  ];

  return (
    <div style={{ padding: '32px 36px' }}>
      <h1 style={{ margin: '0 0 24px', fontSize: 22, fontWeight: 800, color: '#111827' }}>Admin Overview</h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 28 }}>
        {stats.map(s => (
          <div key={s.label} style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 10, padding: '20px 24px' }}>
            <p style={{ margin: '0 0 4px', fontSize: 28, fontWeight: 800, color: s.color, fontFamily: 'monospace' }}>{s.value}</p>
            <p style={{ margin: 0, fontSize: 12, color: COLORS.gray }}>{s.label}</p>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 12 }}>
        <Link href="/admin/review" style={{
          padding: '10px 20px', background: COLORS.navy, color: '#fff',
          borderRadius: 8, textDecoration: 'none', fontSize: 14, fontWeight: 700,
        }}>
          → Score Review Queue
        </Link>
      </div>
    </div>
  );
}
