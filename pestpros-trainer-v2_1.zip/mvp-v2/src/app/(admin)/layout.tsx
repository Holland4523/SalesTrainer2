// src/app/(admin)/layout.tsx
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import Link from 'next/link';
import { COLORS } from '@/types';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase
    .from('users').select('role').eq('id', user.id).single();
  if (profile?.role !== 'super_admin') redirect('/dashboard');

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <aside style={{
        width: 220, background: COLORS.navy, display: 'flex',
        flexDirection: 'column', padding: '20px 0', flexShrink: 0,
      }}>
        <div style={{ padding: '0 20px 20px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
          <p style={{ margin: '0 0 2px', fontSize: 11, fontWeight: 700, color: COLORS.amber, letterSpacing: '0.1em' }}>SUPER ADMIN</p>
          <p style={{ margin: 0, fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>Sales Trainer</p>
        </div>
        <nav style={{ padding: '16px 12px', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {[
            { href: '/admin',        label: '🏠 Overview' },
            { href: '/admin/review', label: '🔍 Score Review' },
          ].map(({ href, label }) => (
            <Link key={href} href={href} style={{
              display: 'block', padding: '9px 12px', borderRadius: 8,
              color: 'rgba(255,255,255,0.8)', textDecoration: 'none', fontSize: 14,
            }}>
              {label}
            </Link>
          ))}
        </nav>
      </aside>
      <main style={{ flex: 1, overflowY: 'auto' }}>{children}</main>
    </div>
  );
}
