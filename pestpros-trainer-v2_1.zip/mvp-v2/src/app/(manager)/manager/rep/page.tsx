// src/app/(manager)/manager/rep/page.tsx
import { redirect } from 'next/navigation';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import Link from 'next/link';
import { scoreColor, COLORS } from '@/types';
import type { Score, Session } from '@/types';

export default async function RepDetailPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string }>;
}) {
  const sp    = await searchParams;
  const repId = sp.id;
  if (!repId) redirect('/manager');

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: viewer } = await supabase
    .from('users').select('role, tenant_id').eq('id', user.id).single();
  if (!viewer || !['manager', 'super_admin'].includes(viewer.role)) redirect('/manager');

  const db = createServiceClient();

  // tenant_id is included so the cross-tenant guard below actually works
  const { data: rep } = await db
    .from('users').select('id, email, full_name, created_at, tenant_id').eq('id', repId).single();

  if (!rep || rep.tenant_id !== viewer.tenant_id) redirect('/manager');

  const [{ data: scores }, { data: sessions }] = await Promise.all([
    db.from('scores')
      .select('*')
      .eq('user_id', repId)
      .order('created_at', { ascending: false })
      .limit(20),
    db.from('sessions')
      .select('id, created_at, difficulty_level, turn_count, status, session_outcome, termination_reason')
      .eq('user_id', repId)
      .order('created_at', { ascending: false })
      .limit(20),
  ]);

  const latest = (scores as Score[])?.[0] ?? null;

  return (
    <div style={{ padding: '32px 36px', maxWidth: 800 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <Link href="/manager" style={{ fontSize: 12, color: COLORS.gray, textDecoration: 'none' }}>← Team</Link>
          <h1 style={{ margin: '4px 0 2px', fontSize: 20, fontWeight: 800, color: '#111827' }}>
            {rep.full_name ?? 'Rep'}
          </h1>
          <p style={{ margin: 0, fontSize: 13, color: COLORS.gray }}>{rep.email}</p>
        </div>
        {latest && (
          <div style={{ textAlign: 'right' }}>
            <p style={{ margin: '0 0 2px', fontSize: 11, color: COLORS.gray, textTransform: 'uppercase', fontWeight: 600 }}>Latest Score</p>
            <p style={{ margin: 0, fontSize: 40, fontWeight: 900, color: scoreColor(latest.readiness_score), fontFamily: 'monospace', lineHeight: 1 }}>
              {latest.readiness_score}
            </p>
          </div>
        )}
      </div>

      {/* Score trend */}
      {(scores as Score[])?.length >= 2 && (
        <div style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 10, padding: '16px 20px', marginBottom: 16, display: 'flex', gap: 24, flexWrap: 'wrap' }}>
          {(scores as Score[]).slice(0, 6).reverse().map((s) => (
            <div key={s.id} style={{ textAlign: 'center' }}>
              <p style={{ margin: '0 0 2px', fontSize: 18, fontWeight: 700, color: scoreColor(s.readiness_score), fontFamily: 'monospace' }}>
                {s.readiness_score}
              </p>
              <p style={{ margin: 0, fontSize: 10, color: COLORS.gray }}>L{s.difficulty_level}</p>
              <p style={{ margin: 0, fontSize: 10, color: COLORS.gray }}>
                {new Date(s.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* Session list */}
      <div style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 10, overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: `1px solid ${COLORS.border}` }}>
          <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: '#374151' }}>Sessions</p>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: COLORS.bg }}>
              {['Date', 'Difficulty', 'Turns', 'Outcome', 'Status', ''].map(h => (
                <th key={h} style={{ padding: '9px 14px', textAlign: 'left', fontWeight: 600, color: COLORS.gray, fontSize: 11, textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {!(sessions?.length) ? (
              <tr><td colSpan={6} style={{ padding: '20px 14px', color: COLORS.gray }}>No sessions yet.</td></tr>
            ) : (sessions as Session[]).map(s => (
              <tr key={s.id} style={{ borderTop: `1px solid ${COLORS.border}` }}>
                <td style={{ padding: '10px 14px' }}>{new Date(s.created_at).toLocaleDateString()}</td>
                <td style={{ padding: '10px 14px' }}>L{s.difficulty_level}</td>
                <td style={{ padding: '10px 14px', fontFamily: 'monospace' }}>{s.turn_count}</td>
                <td style={{ padding: '10px 14px', color: COLORS.gray }}>{s.session_outcome ?? '—'}</td>
                <td style={{ padding: '10px 14px' }}>
                  <span style={{
                    padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 600,
                    background: s.status === 'scored' ? '#E8F5EE' : COLORS.bg,
                    color: s.status === 'scored' ? COLORS.green : COLORS.gray,
                  }}>
                    {s.status}
                  </span>
                </td>
                <td style={{ padding: '10px 14px' }}>
                  <Link href={`/session/transcript?id=${s.id}`} style={{ color: COLORS.steel, fontSize: 12, textDecoration: 'none', fontWeight: 600 }}>
                    Transcript →
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
