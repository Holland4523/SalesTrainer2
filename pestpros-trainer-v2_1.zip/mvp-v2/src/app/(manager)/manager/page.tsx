// src/app/(manager)/manager/page.tsx
import { redirect } from 'next/navigation';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import Link from 'next/link';
import { scoreColor, COLORS } from '@/types';

export default async function ManagerPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase.from('users').select('role, tenant_id').eq('id', user.id).single();
  if (!profile || !['manager','super_admin'].includes(profile.role)) redirect('/dashboard');

  const db = createServiceClient();

  // Get all reps in tenant
  const { data: reps } = await db
    .from('users')
    .select('id, email, full_name, created_at')
    .eq('tenant_id', profile.tenant_id)
    .eq('role', 'rep')
    .order('full_name');

  // Get latest score per rep
  const repIds = (reps ?? []).map(r => r.id);
  const { data: scores } = repIds.length ? await db
    .from('scores')
    .select('user_id, readiness_score, session_outcome, created_at, difficulty_level')
    .in('user_id', repIds)
    .order('created_at', { ascending: false }) : { data: [] };

  // Latest score per rep
  const latestByRep: Record<string, typeof scores[0]> = {};
  for (const s of (scores ?? [])) {
    if (!latestByRep[s.user_id]) latestByRep[s.user_id] = s;
  }

  // Session count per rep (last 7 days)
  const { data: recentSessions } = await db
    .from('sessions')
    .select('user_id')
    .in('user_id', repIds)
    .gte('created_at', new Date(Date.now() - 7 * 86400_000).toISOString());

  const sessionCount: Record<string, number> = {};
  for (const s of (recentSessions ?? [])) {
    sessionCount[s.user_id] = (sessionCount[s.user_id] ?? 0) + 1;
  }

  return (
    <div style={{ padding: '32px 36px', maxWidth: 900 }}>
      <h1 style={{ margin: '0 0 24px', fontSize: 22, fontWeight: 800, color: '#111827' }}>
        Team — {reps?.length ?? 0} reps
      </h1>

      <div style={{ background: '#fff', border: `1px solid ${COLORS.border}`, borderRadius: 12, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: COLORS.bg, borderBottom: `1px solid ${COLORS.border}` }}>
              {['Rep','Latest Score','Difficulty','Outcome','Sessions (7d)',''].map(h => (
                <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontWeight: 600, color: COLORS.gray, fontSize: 11, textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {!(reps?.length) ? (
              <tr><td colSpan={6} style={{ padding: '24px 16px', color: COLORS.gray }}>No reps in this tenant.</td></tr>
            ) : (reps ?? []).map(rep => {
              const ls = latestByRep[rep.id];
              const sc = sessionCount[rep.id] ?? 0;
              const active7d = sc > 0;
              return (
                <tr key={rep.id} style={{ borderTop: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: '12px 16px' }}>
                    <p style={{ margin: 0, fontWeight: 600, color: '#111827' }}>{rep.full_name ?? '—'}</p>
                    <p style={{ margin: '2px 0 0', fontSize: 11, color: COLORS.gray }}>{rep.email}</p>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    {ls ? (
                      <span style={{ fontSize: 18, fontWeight: 800, color: scoreColor(ls.readiness_score), fontFamily: 'monospace' }}>
                        {ls.readiness_score}
                      </span>
                    ) : <span style={{ color: COLORS.gray }}>—</span>}
                  </td>
                  <td style={{ padding: '12px 16px', color: COLORS.gray }}>
                    {ls ? `L${ls.difficulty_level}` : '—'}
                  </td>
                  <td style={{ padding: '12px 16px', color: COLORS.gray }}>
                    {ls?.session_outcome ?? '—'}
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ fontWeight: 700, color: active7d ? COLORS.green : COLORS.red }}>
                      {sc} {!active7d && '⚠'}
                    </span>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <Link href={`/manager/rep?id=${rep.id}`} style={{ color: COLORS.steel, fontSize: 12, textDecoration: 'none', fontWeight: 600 }}>
                      View →
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
