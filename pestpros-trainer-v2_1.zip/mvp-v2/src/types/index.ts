// src/types/index.ts

export type UserRole = 'rep' | 'manager' | 'super_admin';
export type PlanStatus = 'active' | 'failed' | 'cancelled' | 'trialing';
export type SessionStatus = 'pending' | 'active' | 'completed' | 'scoring' | 'scored' | 'scoring_failed';
export type TerminationReason = 'ai_terminated' | 'rep_ended' | 'turn_limit' | 'inactivity_timeout' | 'auth_failure' | 'billing_blocked';
export type SessionQuality = 'valid' | 'abandoned' | 'low_audio_confidence' | 'incomplete' | 'scoring_failed';
export type SpeakerType = 'rep' | 'ai';
export type DifficultyLevel = 1 | 2 | 3 | 4;
export type VoiceState = 'idle' | 'listening' | 'processing' | 'speaking' | 'error';
export type ReviewStatus = 'pending_review' | 'approved' | 'needs_adjustment' | 're_scored';

export type WeakAreaTag =
  | 'price_objection' | 'value_framing' | 'opener_strength' | 'rapport_building'
  | 'question_depth' | 'close_timing' | 'close_attempt_missing' | 'rejection_recovery'
  | 'competitor_objection' | 'urgency_creation' | 'listening_behavior'
  | 'pacing_too_fast' | 'pacing_too_slow' | 'filler_word_overuse'
  | 'response_latency_high' | 'hook_clarity' | 'interruption_recovery';

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  plan_status: PlanStatus;
  seat_count: number;
}

export interface User {
  id: string;
  tenant_id: string;
  role: UserRole;
  email: string;
  full_name: string | null;
  is_active: boolean;
}

export interface Session {
  id: string;
  created_at: string;
  user_id: string;
  tenant_id: string;
  difficulty_level: DifficultyLevel;
  status: SessionStatus;
  termination_reason: TerminationReason | null;
  session_quality: SessionQuality | null;
  session_outcome: string | null;
  turn_count: number;
  max_turns: number;
  scenario_seed: number | null;
  scenario_object: Record<string, unknown> | null;
  started_at: string | null;
  ended_at: string | null;
  scored_at: string | null;
  weak_area_tags: WeakAreaTag[] | null;
}

export interface TranscriptRow {
  id: string;
  session_id: string;
  turn_index: number;
  speaker: SpeakerType;
  text: string;
  created_at: string;
}

export interface Score {
  id: string;
  session_id: string;
  user_id: string;
  tenant_id: string;
  opener_score: number;
  tonality_score: number;
  question_stack_score: number;
  objection_handling_score: number;
  closing_score: number;
  resilience_score: number;
  readiness_score: number;
  raw_readiness_score: number;
  difficulty_level: DifficultyLevel;
  difficulty_multiplier: number;
  scoring_prompt_version: string;
  session_outcome: string | null;
  scoring_notes: string | null;
  review_status: ReviewStatus;
  reviewer_id: string | null;
  reviewer_notes: string | null;
  reviewed_at: string | null;
  score_approved: boolean | null;
  score_adjustment_needed: boolean | null;
  corrected_readiness_score: number | null;
  created_at: string;
}

export interface WeakArea {
  id: string;
  session_id: string;
  tag: WeakAreaTag;
  recommendation: string;
}

// ---------------------------------------------------------------------------
// API request/response shapes
// ---------------------------------------------------------------------------

export interface StartSessionRequest {
  difficulty_level: DifficultyLevel;
}

export interface StartSessionResponse {
  sessionId: string;
  scenarioObject: Record<string, unknown>;
  firstMessage: string;
}

export interface TurnRequest {
  sessionId: string;
  turnText: string;
  audioMetrics?: {
    wpm?: number;
    response_latency_ms?: number;
    filler_word_count?: number;
    amplitude_mean?: number;
  };
}

export interface TurnResponse {
  replyText: string;
  sessionEnded: boolean;
  terminationReason?: TerminationReason;
}

export interface EndSessionRequest {
  sessionId: string;
}

export interface ReviewSubmitRequest {
  scoreId: string;
  outcome: 'approved' | 'needs_adjustment';
  reviewer_notes: string;
  corrected_readiness_score?: number | null;
  corrected_opener_score?: number | null;
  corrected_tonality_score?: number | null;
  corrected_question_stack_score?: number | null;
  corrected_objection_handling_score?: number | null;
  corrected_closing_score?: number | null;
  corrected_resilience_score?: number | null;
}

// ---------------------------------------------------------------------------
// Scoring model output
// ---------------------------------------------------------------------------

export interface ScoringOutput {
  opener_score: number;
  tonality_score: number;
  question_stack_score: number;
  objection_handling_score: number;
  closing_score: number;
  resilience_score: number;
  session_outcome: string;
  weak_area_tags: WeakAreaTag[];
  coaching_recommendations: Array<{ tag: WeakAreaTag; recommendation: string }>;
  scoring_notes: string;
}

export const DIFFICULTY_MULTIPLIERS: Record<DifficultyLevel, number> = {
  1: 1.00,
  2: 1.04,
  3: 1.08,
  4: 1.12,
};

export const SCORE_WEIGHTS = {
  opener_score:             0.22,
  tonality_score:           0.18,
  question_stack_score:     0.15,
  objection_handling_score: 0.25,
  closing_score:            0.10,
  resilience_score:         0.10,
} as const;

export function computeReadinessScore(
  dims: Pick<Score, 'opener_score'|'tonality_score'|'question_stack_score'|'objection_handling_score'|'closing_score'|'resilience_score'>,
  difficultyLevel: DifficultyLevel,
): { readiness_score: number; raw_readiness_score: number; difficulty_multiplier: number } {
  const raw =
    dims.opener_score             * SCORE_WEIGHTS.opener_score +
    dims.tonality_score           * SCORE_WEIGHTS.tonality_score +
    dims.question_stack_score     * SCORE_WEIGHTS.question_stack_score +
    dims.objection_handling_score * SCORE_WEIGHTS.objection_handling_score +
    dims.closing_score            * SCORE_WEIGHTS.closing_score +
    dims.resilience_score         * SCORE_WEIGHTS.resilience_score;

  const multiplier = DIFFICULTY_MULTIPLIERS[difficultyLevel];
  return {
    raw_readiness_score: Math.round(raw * 10) / 10,
    readiness_score:     Math.min(Math.round(raw * multiplier * 10) / 10, 100),
    difficulty_multiplier: multiplier,
  };
}

export function scoreColor(score: number): string {
  if (score >= 75) return '#1E7E4A';
  if (score >= 50) return '#D4860B';
  return '#C0392B';
}

export const COLORS = {
  navy:   '#1B2A4A',
  steel:  '#2E5BA8',
  amber:  '#D4860B',
  red:    '#C0392B',
  green:  '#1E7E4A',
  gray:   '#6B7280',
  border: '#E5E7EB',
  bg:     '#F9FAFB',
};
