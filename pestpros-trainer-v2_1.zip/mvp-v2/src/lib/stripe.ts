// src/lib/stripe.ts
import Stripe from 'stripe';

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY is not set');
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-04-10',
});

export const PLANS = {
  starter: {
    name: 'Starter',
    price: 19,
    sessions: 20,
    priceId: process.env.STRIPE_PRICE_STARTER!,
    description: 'Perfect for individual reps',
    features: ['20 sessions/month', 'All 4 homeowner types', 'All difficulty levels', 'Score breakdown + coaching', 'Session transcripts'],
  },
  pro: {
    name: 'Pro',
    price: 39,
    sessions: 60,
    priceId: process.env.STRIPE_PRICE_PRO!,
    description: 'For serious reps grinding daily',
    features: ['60 sessions/month', 'Everything in Starter', 'Priority AI response', 'Performance trend charts', 'Export transcripts'],
  },
  team: {
    name: 'Team',
    price: 99,
    sessions: null, // unlimited
    priceId: process.env.STRIPE_PRICE_TEAM!,
    description: 'For sales managers and their teams',
    features: ['Unlimited sessions', 'Up to 5 reps', 'Manager dashboard', 'Score review queue', 'Team leaderboard', 'Everything in Pro'],
  },
} as const;

export type PlanKey = keyof typeof PLANS;

export function getSessionLimit(tier: string): number | null {
  if (tier === 'team') return null;
  if (tier === 'pro') return 60;
  if (tier === 'starter') return 20;
  return 3; // free tier
}
