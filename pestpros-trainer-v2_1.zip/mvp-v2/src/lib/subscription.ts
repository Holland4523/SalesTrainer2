// src/lib/subscription.ts
// Server-side helpers for checking subscription status

import { createServiceClient } from '@/lib/supabase/server';

export async function checkSessionAllowance(userId: string): Promise<{
  allowed: boolean;
  reason?: string;
  used: number;
  limit: number | null;
}> {
  const supabase = createServiceClient();

  // Get user + tenant in one join
  const { data: user } = await supabase
    .from('users')
    .select('is_admin, tenant_id, tenants(plan_tier, sub_status, sessions_used_this_period, sessions_limit, current_period_end)')
    .eq('id', userId)
    .single();

  if (!user) return { allowed: false, reason: 'User not found', used: 0, limit: 0 };

  // Admin bypass — always allowed
  if (user.is_admin) return { allowed: true, used: 0, limit: null };

  const tenant = user.tenants as any;
  if (!tenant) return { allowed: false, reason: 'No subscription found', used: 0, limit: 0 };

  // Check subscription is active
  if (tenant.sub_status && !['active', 'trialing'].includes(tenant.sub_status)) {
    return { allowed: false, reason: 'Subscription inactive — please renew', used: tenant.sessions_used_this_period, limit: tenant.sessions_limit };
  }

  // Team = unlimited
  if (tenant.plan_tier === 'team' || tenant.sessions_limit === null) {
    return { allowed: true, used: tenant.sessions_used_this_period, limit: null };
  }

  // Check usage
  const limit = tenant.sessions_limit || 3;
  if (tenant.sessions_used_this_period >= limit) {
    return {
      allowed: false,
      reason: `Monthly limit reached (${tenant.sessions_used_this_period}/${limit}). Upgrade to get more sessions.`,
      used: tenant.sessions_used_this_period,
      limit,
    };
  }

  return { allowed: true, used: tenant.sessions_used_this_period, limit };
}
