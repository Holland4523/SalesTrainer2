// src/lib/openai.ts
// OpenAI service wrapper — simulator turns + post-session scoring

import OpenAI from 'openai';
import type { ScoringOutput, WeakAreaTag, DifficultyLevel } from '@/types';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

const MODEL = 'gpt-4o-mini';

// ---------------------------------------------------------------------------
// TERMINATION SIGNALS
// Strings in the homeowner reply that indicate the session should end
// ---------------------------------------------------------------------------

const TERMINATION_PHRASES = [
  'over.', "i'm not interested.", '[door_closed]', '[session_end]',
  'goodbye.', 'please leave', 'not interested', 'go away',
];

export function detectTermination(text: string): boolean {
  const lower = text.toLowerCase().trim();
  return TERMINATION_PHRASES.some(p => lower.includes(p));
}

// ---------------------------------------------------------------------------
// SIMULATOR TURN
// System prompt is loaded from env — never logged or returned to client
// ---------------------------------------------------------------------------

const SIMULATOR_SYSTEM_PROMPT = process.env.SIMULATOR_SYSTEM_PROMPT;

export interface SimulatorCallOptions {
  history: Array<{ role: 'user' | 'assistant'; content: string }>;
  repTurn: string;
  scenarioContext: string;
}

export interface SimulatorTurnResult {
  replyText: string;
  terminationSignaled: boolean;
  promptTokens: number;
  completionTokens: number;
}

export async function runSimulatorTurn(opts: SimulatorCallOptions): Promise<SimulatorTurnResult> {
  if (!SIMULATOR_SYSTEM_PROMPT) {
    throw new Error('SIMULATOR_SYSTEM_PROMPT env var not set');
  }

  const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
    { role: 'system', content: `${SIMULATOR_SYSTEM_PROMPT}\n\nScenario: ${opts.scenarioContext}` },
    ...opts.history,
    { role: 'user', content: opts.repTurn },
  ];

  const response = await openai.chat.completions.create({
    model:             MODEL,
    messages,
    temperature:       0.85,
    max_tokens:        200,
    presence_penalty:  0.4,
    frequency_penalty: 0.3,
  });

  const replyText = response.choices[0]?.message?.content ?? '';

  return {
    replyText,
    terminationSignaled: detectTermination(replyText),
    promptTokens:     response.usage?.prompt_tokens ?? 0,
    completionTokens: response.usage?.completion_tokens ?? 0,
  };
}

// ---------------------------------------------------------------------------
// SCORING CALL
// ---------------------------------------------------------------------------

const SCORING_SYSTEM_PROMPT = `You are a sales performance evaluator for door-to-door pest control sales reps.

Analyze the transcript and return a JSON object with these exact fields:
{
  "opener_score": <0-100>,
  "tonality_score": <0-100>,
  "question_stack_score": <0-100>,
  "objection_handling_score": <0-100>,
  "closing_score": <0-100>,
  "resilience_score": <0-100>,
  "session_outcome": "<close_attempted|no_close|abandoned>",
  "weak_area_tags": ["<tag>", ...],
  "coaching_recommendations": [{"tag": "<tag>", "recommendation": "<text>"}],
  "scoring_notes": "<brief overall assessment>"
}

Scoring dimensions:
- opener_score (22%): Hook quality, first impression, ability to get attention
- tonality_score (18%): Confidence, warmth, professional presence
- question_stack_score (15%): Discovery questions, listening, uncovering pain points
- objection_handling_score (25%): Handling price/trust/time objections, AVR technique
- closing_score (10%): Asking for the sale, clear call to action
- resilience_score (10%): Recovery after rejection, persistence without being pushy

Valid weak_area_tags: price_objection, value_framing, opener_strength, rapport_building, question_depth, close_timing, close_attempt_missing, rejection_recovery, competitor_objection, urgency_creation, listening_behavior, pacing_too_fast, pacing_too_slow, filler_word_overuse, response_latency_high, hook_clarity, interruption_recovery

Score based on observable behavior in the transcript, not keywords. A rep who narrates rubric phrases without real follow-through should score low.

Return ONLY the JSON object. No markdown, no explanation.`;

export interface ScoringCallOptions {
  transcript: Array<{ speaker: 'rep' | 'ai'; text: string; turn_index: number }>;
  difficultyLevel: DifficultyLevel;
  promptVersion?: string;
}

export interface ScoringCallResult {
  output: ScoringOutput;
  promptTokens: number;
  completionTokens: number;
  estimatedCostUsd: number;
}

export async function runScoringCall(opts: ScoringCallOptions): Promise<ScoringCallResult> {
  const transcriptText = opts.transcript
    .map(t => `[Turn ${t.turn_index} — ${t.speaker.toUpperCase()}]\n"${t.text}"`)
    .join('\n\n');

  const response = await openai.chat.completions.create({
    model:           MODEL,
    temperature:     0.1,
    max_tokens:      1000,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: SCORING_SYSTEM_PROMPT },
      { role: 'user',   content: transcriptText },
    ],
  });

  const raw = response.choices[0]?.message?.content ?? '{}';
  let parsed: ScoringOutput;

  try {
    parsed = JSON.parse(raw) as ScoringOutput;
  } catch {
    throw new Error(`Scoring model returned non-JSON: ${raw.slice(0, 200)}`);
  }

  // Validate and clamp scores
  const dims: (keyof ScoringOutput)[] = [
    'opener_score','tonality_score','question_stack_score',
    'objection_handling_score','closing_score','resilience_score',
  ];
  for (const d of dims) {
    const v = parsed[d] as number;
    (parsed as Record<string, unknown>)[d] = Math.max(0, Math.min(100, v ?? 0));
  }

  // Validate tags
  const VALID_TAGS: WeakAreaTag[] = [
    'price_objection','value_framing','opener_strength','rapport_building',
    'question_depth','close_timing','close_attempt_missing','rejection_recovery',
    'competitor_objection','urgency_creation','listening_behavior',
    'pacing_too_fast','pacing_too_slow','filler_word_overuse',
    'response_latency_high','hook_clarity','interruption_recovery',
  ];
  parsed.weak_area_tags = (parsed.weak_area_tags ?? [])
    .filter((t): t is WeakAreaTag => VALID_TAGS.includes(t as WeakAreaTag))
    .slice(0, 5);

  const promptTokens     = response.usage?.prompt_tokens ?? 0;
  const completionTokens = response.usage?.completion_tokens ?? 0;
  const estimatedCostUsd = (promptTokens / 1000) * 0.00015 + (completionTokens / 1000) * 0.0006;

  return { output: parsed, promptTokens, completionTokens, estimatedCostUsd };
}
