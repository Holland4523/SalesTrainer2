// src/lib/logger.ts
// Fire-and-forget logging utility. Never blocks the hot path.

import { createServiceClient } from '@/lib/supabase/server';

export type LogSeverity = 'debug' | 'info' | 'warning' | 'error' | 'critical';

export interface LogEvent {
  sessionId?:  string;
  tenantId?:   string;
  userId?:     string;
  eventType:   string;
  severity?:   LogSeverity;
  message?:    string;
  metadata?:   Record<string, unknown>;
  turnIndex?:  number;
}

export function log(event: LogEvent): void {
  const db = createServiceClient();
  db.from('orchestrator_logs')
    .insert({
      session_id: event.sessionId,
      tenant_id:  event.tenantId,
      user_id:    event.userId,
      event_type: event.eventType,
      severity:   event.severity ?? 'info',
      message:    event.message,
      metadata:   event.metadata ?? {},
      turn_index: event.turnIndex,
    })
    .then(({ error }) => {
      if (error) console.error('[logger] write failed:', error.message);
    });
}

export function logError(
  eventType: string,
  err: unknown,
  context?: Omit<LogEvent, 'eventType' | 'severity'>,
): void {
  const msg = err instanceof Error ? err.message : String(err);
  log({ ...context, eventType, severity: 'error', message: msg });
  console.error(`[${eventType}]`, msg);
}
