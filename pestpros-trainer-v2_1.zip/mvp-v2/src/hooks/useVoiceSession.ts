'use client';
// src/hooks/useVoiceSession.ts
// Uses server-side Whisper (transcription) + OpenAI TTS (speech output)
// No API key ever touches the browser — all calls go through /api/session/

import { useState, useRef, useCallback, useEffect } from 'react';
import type { VoiceState } from '@/types';

const FILLER_WORDS = ['um','uh','like','so','basically','literally','you know','kind of','sort of'];

function countFillers(text: string): number {
  const lower = text.toLowerCase();
  return FILLER_WORDS.reduce((n, w) =>
    n + (lower.match(new RegExp(`\\b${w}\\b`, 'g'))?.length ?? 0), 0);
}

interface UseVoiceSessionOptions {
  sessionId: string;
  onTurnComplete: (reply: string, ended: boolean, reason?: string) => void;
  onError: (msg: string) => void;
}

export function useVoiceSession({ sessionId, onTurnComplete, onError }: UseVoiceSessionOptions) {
  const [voiceState,  setVoiceState]  = useState<VoiceState>('idle');
  const [transcript,  setTranscript]  = useState('');
  const [turnCount,   setTurnCount]   = useState(0);
  const [isSupported, setIsSupported] = useState(true);

  const recorderRef   = useRef<MediaRecorder | null>(null);
  const chunksRef     = useRef<Blob[]>([]);
  const turnStartRef  = useRef(0);
  const currentAudio  = useRef<HTMLAudioElement | null>(null);
  const isMounted     = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    if (!navigator.mediaDevices?.getUserMedia) {
      setIsSupported(false);
    }
    return () => { isMounted.current = false; };
  }, []);

  // ── RECORD ─────────────────────────────────────────────────
  const startListening = useCallback(async () => {
    if (voiceState !== 'idle') return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mime   = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/ogg';
      const rec    = new MediaRecorder(stream, { mimeType: mime });
      chunksRef.current = [];
      rec.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      rec.start(100);
      recorderRef.current = rec;
      turnStartRef.current = Date.now();
      if (isMounted.current) setVoiceState('listening');
    } catch (err) {
      onError('Microphone access denied. Allow mic and try again.');
    }
  }, [voiceState, onError]);

  // ── STOP + TRANSCRIBE + TURN ────────────────────────────────
  const stopListening = useCallback(async () => {
    if (voiceState !== 'listening' || !recorderRef.current) return;
    const rec = recorderRef.current;

    // Stop recorder
    await new Promise<void>(res => { rec.onstop = () => res(); rec.stop(); });
    rec.stream.getTracks().forEach(t => t.stop());

    const blob = new Blob(chunksRef.current, { type: rec.mimeType });
    if (blob.size < 500) {
      if (isMounted.current) setVoiceState('idle');
      return;
    }

    if (isMounted.current) setVoiceState('processing');

    // 1. Transcribe via server-side Whisper
    let repText = '';
    try {
      const fd = new FormData();
      fd.append('audio', blob, 'audio.webm');
      const tRes = await fetch('/api/session/transcribe', { method: 'POST', body: fd });
      const tData = await tRes.json();
      if (!tRes.ok) throw new Error(tData.error ?? 'Transcription failed');
      repText = tData.text?.trim() ?? '';
    } catch (err) {
      if (isMounted.current) { setVoiceState('error'); onError((err as Error).message); }
      return;
    }

    if (!repText) {
      if (isMounted.current) setVoiceState('idle');
      return;
    }

    if (isMounted.current) setTranscript(repText);

    // 2. Send turn to simulator
    const latencyMs = Date.now() - turnStartRef.current;
    let replyText = '';
    let sessionEnded = false;
    let terminationReason: string | undefined;

    try {
      const tRes = await fetch('/api/session/turn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          turnText: repText,
          audioMetrics: {
            wpm: Math.round((repText.split(/\s+/).length / latencyMs) * 60_000),
            response_latency_ms: latencyMs,
            filler_word_count: countFillers(repText),
            amplitude_mean: 0,
          },
        }),
      });
      const tData = await tRes.json();
      if (!tRes.ok) throw new Error(tData.error ?? 'Turn failed');
      replyText        = tData.replyText;
      sessionEnded     = tData.sessionEnded ?? false;
      terminationReason = tData.terminationReason;
    } catch (err) {
      if (isMounted.current) { setVoiceState('error'); onError((err as Error).message); }
      return;
    }

    // 3. Play homeowner voice via server-side TTS
    if (isMounted.current) setVoiceState('speaking');
    await speakViaServer(replyText, currentAudio);

    if (isMounted.current) {
      setTurnCount(n => n + 1);
      setVoiceState('idle');
      onTurnComplete(replyText, sessionEnded, terminationReason);
    }
  }, [voiceState, sessionId, onTurnComplete, onError]);

  const skipSpeech = useCallback(() => {
    if (currentAudio.current) {
      currentAudio.current.pause();
      currentAudio.current = null;
    }
    if (isMounted.current) setVoiceState('idle');
  }, []);

  return { voiceState, transcript, turnCount, isSupported, startListening, stopListening, skipSpeech };
}

// Fetch TTS audio from server, play it, resolve when done
async function speakViaServer(text: string, audioRef: React.MutableRefObject<HTMLAudioElement | null>): Promise<void> {
  try {
    const res = await fetch('/api/session/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
    if (!res.ok) return; // fail silently — speech is non-critical
    const blob = await res.blob();
    const url  = URL.createObjectURL(blob);
    await new Promise<void>(resolve => {
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => { URL.revokeObjectURL(url); resolve(); };
      audio.onerror = () => { URL.revokeObjectURL(url); resolve(); };
      audio.play().catch(() => resolve());
    });
    audioRef.current = null;
  } catch {
    // TTS failure is non-fatal — session continues
  }
}
