'use client';
// src/hooks/useScorePolling.ts

import { useState, useEffect, useRef } from 'react';
import { createClient } from '@/lib/supabase/client';
import type { Score, WeakArea } from '@/types';

interface UseScorePollingResult {
  score:     Score | null;
  weakAreas: WeakArea[];
  isLoading: boolean;
  isError:   boolean;
}

export function useScorePolling(sessionId: string | null): UseScorePollingResult {
  const [score,     setScore]     = useState<Score | null>(null);
  const [weakAreas, setWeakAreas] = useState<WeakArea[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isError,   setIsError]   = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const attemptsRef = useRef(0);

  useEffect(() => {
    if (!sessionId) return;
    const supabase = createClient();

    async function poll() {
      attemptsRef.current++;
      if (attemptsRef.current > 40) { // ~100s timeout
        setIsLoading(false);
        setIsError(true);
        if (intervalRef.current) clearInterval(intervalRef.current);
        return;
      }

      const { data: session } = await supabase
        .from('sessions').select('status').eq('id', sessionId).single();

      if (session?.status === 'scored') {
        const [{ data: scoreData }, { data: waData }] = await Promise.all([
          supabase.from('scores').select('*').eq('session_id', sessionId).single(),
          supabase.from('weak_areas').select('*').eq('session_id', sessionId),
        ]);
        setScore(scoreData as Score ?? null);
        setWeakAreas(waData as WeakArea[] ?? []);
        setIsLoading(false);
        if (intervalRef.current) clearInterval(intervalRef.current);
      } else if (session?.status === 'scoring_failed') {
        setIsLoading(false);
        setIsError(true);
        if (intervalRef.current) clearInterval(intervalRef.current);
      }
    }

    intervalRef.current = setInterval(poll, 2500);
    poll();

    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [sessionId]);

  return { score, weakAreas, isLoading, isError };
}
