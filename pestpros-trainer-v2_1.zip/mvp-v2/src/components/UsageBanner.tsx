'use client';
// src/components/UsageBanner.tsx
// Shows subscription status and usage at top of dashboard

const C = {
  amber: '#F59E0B', amberBg: 'rgba(245,158,11,.1)',
  red: '#EF4444', redBg: 'rgba(239,68,68,.1)',
  green: '#10B981', greenBg: 'rgba(16,185,129,.1)',
  border: '#ffffff0d', muted: 'rgba(239,246,255,.55)',
  faint: 'rgba(239,246,255,.22)',
};

interface Props {
  plan: string;
  used: number;
  limit: number | null;
  isAdmin: boolean;
  subStatus?: string;
  periodEnd?: string;
}

export function UsageBanner({ plan, used, limit, isAdmin, subStatus, periodEnd }: Props) {
  const pct = limit ? Math.round((used / limit) * 100) : 0;
  const nearLimit = limit && used >= limit * 0.8;
  const atLimit   = limit && used >= limit;
  const isPastDue = subStatus === 'past_due';

  async function goPortal() {
    const res = await fetch('/api/stripe/portal', { method: 'POST' });
    const { url } = await res.json();
    if (url) window.location.href = url;
  }

  if (isAdmin) return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 14px', background: C.greenBg, border: `1px solid ${C.green}30`, borderRadius: 7, marginBottom: 20 }}>
      <span style={{ fontSize: 11, color: C.green, fontFamily: 'monospace', letterSpacing: '.1em', fontWeight: 700 }}>ADMIN</span>
      <span style={{ fontSize: 12, color: C.muted }}>Unlimited access · billing bypassed</span>
    </div>
  );

  if (isPastDue) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', background: C.redBg, border: `1px solid ${C.red}40`, borderRadius: 7, marginBottom: 20 }}>
      <div>
        <span style={{ fontSize: 11, color: C.red, fontFamily: 'monospace', letterSpacing: '.1em', fontWeight: 700, marginRight: 10 }}>⚠ PAYMENT FAILED</span>
        <span style={{ fontSize: 12, color: C.muted }}>Please update your payment method to continue.</span>
      </div>
      <button onClick={goPortal} style={{ padding: '5px 13px', background: C.red, color: '#fff', border: 'none', borderRadius: 5, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>Fix Now</button>
    </div>
  );

  const color = atLimit ? C.red : nearLimit ? C.amber : C.green;
  const bg    = atLimit ? C.redBg : nearLimit ? C.amberBg : C.greenBg;

  return (
    <div style={{ padding: '10px 14px', background: bg, border: `1px solid ${color}30`, borderRadius: 7, marginBottom: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: limit ? 6 : 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 11, color, fontFamily: 'monospace', letterSpacing: '.1em', fontWeight: 700 }}>{plan.toUpperCase()}</span>
          <span style={{ fontSize: 12, color: C.muted }}>
            {limit ? `${used} / ${limit} sessions used this month` : `${used} sessions used · unlimited`}
          </span>
          {periodEnd && <span style={{ fontSize: 11, color: C.faint }}>· renews {new Date(periodEnd).toLocaleDateString()}</span>}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {atLimit && <a href="/pricing" style={{ padding: '4px 12px', background: C.amber, color: '#000', borderRadius: 5, fontSize: 12, fontWeight: 700, textDecoration: 'none' }}>Upgrade →</a>}
          {plan !== 'free' && <button onClick={goPortal} style={{ padding: '4px 12px', background: 'transparent', color: C.faint, border: `1px solid ${C.border}`, borderRadius: 5, fontSize: 11, cursor: 'pointer' }}>Manage</button>}
        </div>
      </div>
      {limit && (
        <div style={{ height: 4, background: '#ffffff0d', borderRadius: 2 }}>
          <div style={{ height: '100%', width: `${Math.min(100, pct)}%`, background: color, borderRadius: 2, transition: 'width .5s ease' }} />
        </div>
      )}
    </div>
  );
}
