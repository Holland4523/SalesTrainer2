# PestPros AI Sales Trainer — Deploy Guide
**Time to live: ~20 minutes**

---

## Prerequisites
- GitHub account (free)
- Supabase account (free) → supabase.com
- Stripe account (already have) → dashboard.stripe.com
- Vercel account (free) → vercel.com
- OpenAI API key → platform.openai.com

---

## Step 1 — Stripe Setup (5 min)

### 1a. Get your API keys
Go to https://dashboard.stripe.com/apikeys
- Copy **Secret key** (sk_live_...)
- Copy **Publishable key** (pk_live_...)

### 1b. Create 3 subscription products
Go to https://dashboard.stripe.com/products → **+ Add product**

Create each one:
| Product Name | Price | Billing |
|---|---|---|
| PestPros Starter | $19.00 | Monthly recurring |
| PestPros Pro | $39.00 | Monthly recurring |
| PestPros Team | $99.00 | Monthly recurring |

After creating each, click into it and copy the **Price ID** (looks like `price_1ABC...`)
Save all 3 price IDs — you'll need them in Step 3.

### 1c. Set up webhook (do this after Step 4 — Vercel)
Come back here after deploying. Go to:
https://dashboard.stripe.com/webhooks → **+ Add endpoint**
- Endpoint URL: `https://YOUR-VERCEL-URL.vercel.app/api/stripe/webhook`
- Events to listen for:
  - `checkout.session.completed`
  - `invoice.payment_succeeded`
  - `invoice.payment_failed`
  - `customer.subscription.deleted`
- Copy the **Webhook signing secret** (whsec_...)

---

## Step 2 — Supabase Setup (5 min)

### 2a. Create project
Go to https://supabase.com → New project
- Name: `pestpros-trainer`
- Password: (save it somewhere)
- Region: US East (or closest to you)

### 2b. Run the schema
Go to **SQL Editor** in your Supabase dashboard
Open `sql/schema.sql` from this repo
Paste the entire contents → **Run**

### 2c. Get your keys
Go to **Project Settings → API**
- Copy **Project URL** (https://xxx.supabase.co)
- Copy **anon public key**
- Copy **service_role secret key** (keep this secret)

### 2d. Configure Auth
Go to **Authentication → Settings**
- Site URL: `https://YOUR-VERCEL-URL.vercel.app`
- Redirect URLs: add `https://YOUR-VERCEL-URL.vercel.app/**`
- Email confirmations: enabled by default (good)

---

## Step 3 — GitHub (2 min)

1. Create a new **private** repo at github.com
2. Push this codebase:
```bash
cd /path/to/mvp-v2
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

---

## Step 4 — Vercel Deploy (5 min)

1. Go to https://vercel.com → **Add New Project**
2. Import your GitHub repo
3. Framework: **Next.js** (auto-detected)
4. Root directory: leave as `/`
5. Click **Environment Variables** and add ALL of these:

```
NEXT_PUBLIC_SUPABASE_URL         = https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY    = your-anon-key
SUPABASE_SERVICE_ROLE_KEY        = your-service-role-key

OPENAI_API_KEY                   = sk-your-openai-key
SIMULATOR_SYSTEM_PROMPT          = [see below]

STRIPE_SECRET_KEY                = sk_live_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = pk_live_...
STRIPE_WEBHOOK_SECRET            = whsec_... (add after Step 1c)
STRIPE_PRICE_STARTER             = price_...
STRIPE_PRICE_PRO                 = price_...
STRIPE_PRICE_TEAM                = price_...

ADMIN_EMAIL                      = YOUR-EMAIL@gmail.com
NEXT_PUBLIC_APP_URL              = https://YOUR-APP.vercel.app
INTERNAL_API_KEY                 = [generate: openssl rand -hex 16]
```

6. Click **Deploy**

### SIMULATOR_SYSTEM_PROMPT value:
```
You are a homeowner answering a door-to-door pest control sales rep. Stay in character. Keep replies 1-3 sentences. React naturally to rep quality — warm up if they're good, stay cold if they're weak.
```

---

## Step 5 — Set up Stripe Webhook

Now that you have your Vercel URL, go back to Step 1c and add the webhook endpoint.
Copy the webhook signing secret and add it to Vercel:
- **Vercel → Project → Settings → Environment Variables**
- Add: `STRIPE_WEBHOOK_SECRET` = `whsec_...`
- Redeploy: Vercel → Deployments → three dots → Redeploy

---

## Step 6 — Test everything (3 min)

1. Go to your app URL
2. Sign up with your **ADMIN_EMAIL** — you get unlimited free access automatically
3. Try starting a session — it should use Whisper + GPT-4o-mini + TTS
4. Test a purchase with Stripe test card `4242 4242 4242 4242` (switch to test mode first)
5. Check Supabase → Table Editor → `tenants` to verify plan_tier updated after checkout

---

## Admin access

Sign in with the email you set as `ADMIN_EMAIL`.
- Bypasses all billing checks
- Unlimited sessions
- Access to admin review queue at `/admin`

---

## Troubleshooting

**Sessions not starting:** Check `OPENAI_API_KEY` and `SIMULATOR_SYSTEM_PROMPT` are set in Vercel

**Stripe checkout failing:** Verify `STRIPE_SECRET_KEY` and all 3 `STRIPE_PRICE_*` IDs are correct

**Auth not working:** Check Supabase Auth → Settings → Site URL matches your Vercel URL

**Webhook not firing:** Make sure you added all 4 event types and the URL ends in `/api/stripe/webhook`

---

## Cost estimate (monthly)

| Item | Cost |
|---|---|
| Vercel (hobby) | Free |
| Supabase (free tier) | Free |
| OpenAI per session | ~$0.03–0.08 |
| Stripe fees | 2.9% + 30¢ per transaction |

At 100 paying sessions/month across users: ~$5–8 OpenAI cost.
At $19/mo Starter with 20 sessions: your margin is ~85%.

