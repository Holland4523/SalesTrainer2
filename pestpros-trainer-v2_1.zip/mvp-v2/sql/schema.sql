-- ═══════════════════════════════════════════════════════════════
-- PestPros AI Sales Trainer — Full Schema v2
-- Run this entire file in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════════

-- ── EXTENSIONS ────────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── ENUMS ─────────────────────────────────────────────────────
do $$ begin
  create type user_role       as enum ('rep', 'manager', 'super_admin');
  create type plan_tier       as enum ('free', 'starter', 'pro', 'team');
  create type sub_status      as enum ('active', 'canceled', 'past_due', 'trialing');
  create type session_status  as enum ('active', 'ended', 'scored', 'failed');
  create type review_status   as enum ('pending_review', 'approved', 'needs_adjustment');
  create type difficulty_level as enum ('1', '2', '3', '4');
exception when duplicate_object then null; end $$;

-- ── TENANTS ───────────────────────────────────────────────────
create table if not exists public.tenants (
  id                uuid primary key default uuid_generate_v4(),
  name              text not null,
  slug              text unique not null,
  -- Stripe
  stripe_customer_id   text unique,
  stripe_subscription_id text unique,
  stripe_price_id      text,
  plan_tier            plan_tier not null default 'free',
  sub_status           sub_status,
  current_period_end   timestamptz,
  -- Usage
  sessions_used_this_period integer not null default 0,
  sessions_limit           integer,          -- null = unlimited (admin/team)
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ── USERS ─────────────────────────────────────────────────────
create table if not exists public.users (
  id          uuid primary key references auth.users(id) on delete cascade,
  tenant_id   uuid not null references public.tenants(id) on delete cascade,
  email       text not null,
  full_name   text,
  role        user_role not null default 'rep',
  is_admin    boolean not null default false,   -- true = ADMIN_EMAIL bypass
  created_at  timestamptz not null default now()
);
create index if not exists users_tenant_idx on public.users(tenant_id);
create index if not exists users_email_idx  on public.users(email);

-- ── SESSIONS ──────────────────────────────────────────────────
create table if not exists public.sessions (
  id              uuid primary key default uuid_generate_v4(),
  tenant_id       uuid not null references public.tenants(id),
  user_id         uuid not null references public.users(id),
  scenario_type   text not null,
  difficulty      difficulty_level not null default '2',
  status          session_status not null default 'active',
  turn_count      integer not null default 0,
  started_at      timestamptz not null default now(),
  ended_at        timestamptz,
  scored_at       timestamptz
);
create index if not exists sessions_user_idx   on public.sessions(user_id);
create index if not exists sessions_tenant_idx on public.sessions(tenant_id);

-- ── TRANSCRIPTS ───────────────────────────────────────────────
create table if not exists public.session_transcripts (
  id          uuid primary key default uuid_generate_v4(),
  session_id  uuid not null references public.sessions(id) on delete cascade,
  turn_number integer not null,
  speaker     text not null check (speaker in ('rep','ai')),
  content     text not null,
  created_at  timestamptz not null default now()
);

-- ── SCORES ────────────────────────────────────────────────────
create table if not exists public.scores (
  id              uuid primary key default uuid_generate_v4(),
  session_id      uuid not null unique references public.sessions(id),
  tenant_id       uuid not null references public.tenants(id),
  user_id         uuid not null references public.users(id),
  -- Raw model scores
  opener          integer check (opener between 0 and 100),
  tonality        integer check (tonality between 0 and 100),
  discovery       integer check (discovery between 0 and 100),
  objections      integer check (objections between 0 and 100),
  closing         integer check (closing between 0 and 100),
  resilience      integer check (resilience between 0 and 100),
  readiness_score integer check (readiness_score between 0 and 100),
  outcome         text,
  coaching_notes  text,
  -- Admin review
  review_status   review_status not null default 'pending_review',
  reviewed_by     uuid references public.users(id),
  reviewed_at     timestamptz,
  reviewer_notes  text,
  -- Corrected scores (after review)
  corrected_readiness integer,
  created_at      timestamptz not null default now()
);

-- ── STRIPE EVENTS LOG ─────────────────────────────────────────
create table if not exists public.stripe_events (
  id          text primary key,   -- Stripe event id
  type        text not null,
  tenant_id   uuid references public.tenants(id),
  payload     jsonb,
  processed_at timestamptz not null default now()
);

-- ── RLS ───────────────────────────────────────────────────────
alter table public.tenants              enable row level security;
alter table public.users                enable row level security;
alter table public.sessions             enable row level security;
alter table public.session_transcripts  enable row level security;
alter table public.scores               enable row level security;
alter table public.stripe_events        enable row level security;

-- Helper: get current user's tenant_id
create or replace function public.my_tenant_id()
returns uuid language sql security definer stable as $$
  select tenant_id from public.users where id = auth.uid();
$$;

-- Helper: get current user's role
create or replace function public.my_role()
returns user_role language sql security definer stable as $$
  select role from public.users where id = auth.uid();
$$;

-- Helper: is current user admin bypass
create or replace function public.is_admin()
returns boolean language sql security definer stable as $$
  select coalesce(is_admin, false) from public.users where id = auth.uid();
$$;

-- Tenant policies
create policy "tenant_self" on public.tenants for select
  using (id = public.my_tenant_id() or public.is_admin());

-- User policies
create policy "users_same_tenant" on public.users for select
  using (tenant_id = public.my_tenant_id() or public.is_admin());
create policy "users_self_update" on public.users for update
  using (id = auth.uid());

-- Session policies
create policy "sessions_same_tenant" on public.sessions for select
  using (tenant_id = public.my_tenant_id() or public.is_admin());
create policy "sessions_own_insert" on public.sessions for insert
  with check (user_id = auth.uid() and tenant_id = public.my_tenant_id());
create policy "sessions_own_update" on public.sessions for update
  using (user_id = auth.uid() or public.my_role() in ('manager','super_admin') or public.is_admin());

-- Transcript policies
create policy "transcripts_same_tenant" on public.session_transcripts for select
  using (exists (select 1 from public.sessions s where s.id = session_id and s.tenant_id = public.my_tenant_id()) or public.is_admin());
create policy "transcripts_own_insert" on public.session_transcripts for insert
  with check (exists (select 1 from public.sessions s where s.id = session_id and s.user_id = auth.uid()));

-- Score policies
create policy "scores_same_tenant" on public.scores for select
  using (tenant_id = public.my_tenant_id() or public.is_admin());
create policy "scores_service_insert" on public.scores for insert
  with check (true);  -- service role only; RLS bypassed server-side
create policy "scores_manager_update" on public.scores for update
  using (public.my_role() in ('manager','super_admin') or public.is_admin());

-- Stripe events — service role only
create policy "stripe_events_deny_all" on public.stripe_events for select using (false);

-- ── FUNCTION: increment session usage ─────────────────────────
create or replace function public.increment_session_usage(p_tenant_id uuid)
returns void language plpgsql security definer as $$
begin
  update public.tenants
  set sessions_used_this_period = sessions_used_this_period + 1,
      updated_at = now()
  where id = p_tenant_id;
end;
$$;

-- ── FUNCTION: reset usage on renewal ──────────────────────────
create or replace function public.reset_period_usage(p_tenant_id uuid)
returns void language plpgsql security definer as $$
begin
  update public.tenants
  set sessions_used_this_period = 0,
      updated_at = now()
  where id = p_tenant_id;
end;
$$;

-- ── TRIGGER: update updated_at ────────────────────────────────
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;
create or replace trigger tenants_updated_at
  before update on public.tenants
  for each row execute function public.set_updated_at();
