# Sales Trainer MVP

Voice-first door-to-door pest control sales training simulator.

## Stack

- Next.js 14 App Router
- TypeScript
- Supabase (Postgres + Auth + RLS)
- OpenAI gpt-4o-mini
- Vercel

## Setup

### 1. Install

```bash
npm install
```

### 2. Supabase

Create a project at supabase.com.

Run `sql/schema.sql` in the Supabase SQL editor.

Enable Auth > Email provider.

Configure JWT claims hook to inject `tenant_id` and `role` into the JWT:

```sql
-- In Supabase Auth > Hooks, add a custom access token hook:
-- Function: auth.custom_access_token_hook
CREATE OR REPLACE FUNCTION auth.custom_access_token_hook(event jsonb)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE
  claims jsonb;
  user_data record;
BEGIN
  SELECT tenant_id, role INTO user_data
    FROM public.users WHERE id = (event->>'user_id')::uuid;

  claims := event->'claims';
  claims := jsonb_set(claims, '{tenant_id}', to_jsonb(user_data.tenant_id::text));
  claims := jsonb_set(claims, '{role}', to_jsonb(user_data.role::text));
  RETURN jsonb_set(event, '{claims}', claims);
END;
$$;
```

### 3. Environment variables

Copy `.env.example` to `.env.local` and fill in all values.

`SIMULATOR_SYSTEM_PROMPT` must contain your frozen homeowner simulator instructions. The server will throw on startup if this is missing.

### 4. Bootstrap super-admin

After creating your first user account:

```sql
UPDATE users SET role = 'super_admin' WHERE email = 'your@email.com';
UPDATE tenants SET plan_status = 'active' WHERE id = (SELECT tenant_id FROM users WHERE email = 'your@email.com');
```

### 5. Run

```bash
npm run dev
```

### 6. Deploy to Vercel

```bash
vercel deploy
```

Add all env vars in Vercel project settings.

---

## Route map

| Path | Role | Description |
|------|------|-------------|
| `/dashboard` | rep | Readiness score, trend, history |
| `/session/new` | rep | Difficulty selection + mic check |
| `/session/active?id=` | rep | Live voice simulation |
| `/session/results?id=` | rep | Post-session score + coaching |
| `/session/transcript?id=` | rep/manager | Full transcript viewer |
| `/manager` | manager | Team rep list |
| `/manager/rep?id=` | manager | Individual rep detail |
| `/admin` | super_admin | Platform overview |
| `/admin/review` | super_admin | Alpha gate review queue |
| `/admin/review/:scoreId` | super_admin | Full session review form |

## API routes

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/session/start` | POST | Create session, return first AI turn |
| `/api/session/turn` | POST | Process one rep turn |
| `/api/session/end` | POST | Rep-initiated termination |
| `/api/session/score` | POST | Internal scoring trigger (guarded) |
| `/api/session/transcript` | GET | Load transcript for active session |
| `/api/admin/review` | GET | Review queue |
| `/api/admin/review` | POST | Submit review decision |
| `/api/admin/review/:scoreId` | GET | Full review bundle |

---

## Alpha validation gate

After 15+ sessions are scored, review each one at `/admin/review`.

Gate passes when:
- All included sessions are approved
- Avg |corrected − model| delta ≤ 12 pts
- Tag match rate ≥ 80%

Activate prompt after gate passes:
```sql
UPDATE scoring_prompt_versions
SET is_active = true, activated_at = now()
WHERE version = 'v1.0';
```
